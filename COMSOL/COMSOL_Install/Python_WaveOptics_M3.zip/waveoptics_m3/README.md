# Python Wave Optics M3

M1 슬랩 모드, M2 혼합 Nédélec–Lagrange 벡터 모드, M3 2D 주파수 영역 TE/TM 산란 및 전파 솔버를 포함합니다. 정확도 주장은 제공된 해석 기준과 검증 조건에 한정됩니다. COMSOL 결과와 대조하지 않았습니다.

## 설치

Python **3.11**이 필요합니다. Linux에서 gmsh를 위해 `libglu1-mesa`, `libxft2`가 필요할 수 있습니다.

```bash
python3.11 -m venv .venv
. .venv/bin/activate
python -m pip install -e '.[test]'
OPENBLAS_NUM_THREADS=1 python -m pytest -q
OPENBLAS_NUM_THREADS=1 python validate_m3.py
wave-scatter guide --polarization TE --h .02 --layer-index 1.6 --full-s --out runs/layer_TE
wave-scatter cylinder --polarization TM --h .02 --index 1.5 --out runs/cylinder_TM
```

CLI는 `fields.npz`, `summary.json`, `field.png`를 저장합니다. `--full-s`는 `s_matrix.npz`를 추가합니다. JSON 복소수는 `[실수부, 허수부]`입니다. S 행렬은 출력 채널이 행, 입사 채널이 열이며 채널 순서는 왼쪽 전파 모드 전체 다음 오른쪽 전파 모드 전체입니다. 모드 번호는 0부터 시작하고 Reβ가 큰 순서입니다.

## 정식화

솔버 작성 전 수식은 [M3_FORMULATION.md](M3_FORMULATION.md)에 보존했습니다. 시간 `exp(-iωt)`, 평면 x,y, 불변 방향 z이며 **TE=E_z, TM=H_z**입니다. M1의 전파 방향과 혼동하지 마십시오.

`div(p grad u)+k0²q u=0`; TE `(p,q)=(1,n²)`, TM `(p,q)=(1/n²,1)`입니다. 재료 경계에서 u와 p∂nu가 연속입니다. Cartesian PML `sx=1+iσx, sy=1+iσy`에 대해 `D=p diag(sy/sx,sx/sy), Q=q sx sy`를 조립합니다. `σ=strength (d/thickness)^power`이며 코너는 두 신장을 모두 적용합니다.

체적은 삼각형 P1과 6차 적분, 포트는 경계 노드를 공유하는 선분 P1과 6점 Gauss 적분입니다. `Kφ-k0²Mqφ=-β²Mpφ`, `φ*Mpφ=1`; 모든 유한 trace 고유벡터를 유지하여 소멸 모드까지 DtN에 포함합니다. DtN 행렬은 `MpΦ diag(β)Φ*Mp`입니다. 전파 β는 양의 실수, 소멸 β는 양의 허수입니다.

약형식 `a(u,v)=∫D grad u·grad v̅-k0²Quv̅-iΣ〈Tu,v〉`의 입사 부하는 `-2i〈Tuinc,v〉`입니다. 출력 계수에서 입사 진폭을 빼고 `Smi=bm sqrt(βm/βi)`로 전력 정규화합니다. 포트 재료는 실수 무손실이어야 합니다. PEC 벽은 TE u=0, TM p∂nu=0입니다. 좌우 외곽이 포트 기준면이며 S21은 기준면 사이 전파 위상을 포함합니다. De-embedding은 하지 않습니다.

평면파 산란은 산란장 us를 풉니다. `ui=exp(ikb d·x)`이고 부하는 `-∫(p-pb)grad ui·grad v̅+k0²∫(q-qb)ui v̅`입니다. contrast는 PML과 겹칠 수 없습니다. 외곽 us=0이고 물리 영역에서 총장 ui+us를 복원합니다.

## API

```python
import numpy as np
from waveoptics.scattering import guide_mesh, solve_ports, solve_s_matrix
mesh = guide_mesh([0, .3, .55, .9], [0, .6], .02)
def n(x):
    return np.where((x[0] > .3) & (x[0] < .55), 1.6 + .03j, 1.2)
sol = solve_ports(mesh, n, wavelength_um=1., polarization='TE')
S, channels, diagnostics = solve_s_matrix(mesh, n, 1., 'TE')
sol.save_npz('fields.npz')
```

```python
from waveoptics.scattering import PML, cylinder_mesh, solve_plane_wave
pml = PML((-.8, .8), (-.8, .8), left=.6, right=.6, bottom=.6, top=.6)
mesh = cylinder_mesh(.2, pml, .02)
sol = solve_plane_wave(mesh, 1.5, 1., 1., 'TM', pml)
width_um = sol.scattering_width(.55, orders=8, samples=1440)
xy, weights, E, H = sol.quadrature_fields(total=True)
```

불연속 재료 경계와 메시 subdomain 경계를 일치시킵니다. 직사각형 nominal h는 해상도 입력이며 좌표 간격은 h/3 이하입니다. 실제 최대 변 길이는 diagnostics에 별도로 보고합니다. 원통은 gmsh size h를 사용하고 직선 경계로 원을 근사하므로 실제 hmax는 h와 다릅니다.

`solve_plane_wave`의 `n_inside`를 callable로 주면 직사각형 PML 외곽을 가진 다른 `VectorMesh`에도 굴절률 분포를 적용할 수 있습니다. 임의 분포 정확도는 별도 검증이 필요합니다. 원통의 scalar index는 CAD 라벨을 사용하여 quadrature에서 원을 재분류하지 않습니다.

## 출력과 단위

길이·진공 파장은 μm, β는 μm⁻¹입니다. 재료 분산은 사용자가 각 파장의 n으로 제공해야 합니다.

- `s_parameters`: 전파 모드의 복소 계수. `abs(S)**2`는 입사 전력에 대한 비율입니다. `1-R-T`는 흡수와 미해결 수치 오차를 함께 포함하므로 수렴 검토가 필요합니다.
- `field`: 포트 해석은 총장, 평면파 해석은 산란장입니다. 평면파에서 `sample(xy,total=True)`는 총장을 반환합니다.
- `quadrature_fields`: Maxwell 식으로 E,H를 복원합니다. TE scalar 입사 진폭은 E_z, TM scalar 입사 진폭은 H_z이며 기본장이 1 W는 아닙니다. `Z0≈376.7303 Ω`을 사용합니다. PML 내부 값은 복소 신장 계산장입니다.
- `scattering_width`: 2D 산란폭 [μm]으로 3D 단면적 [μm²]과 다릅니다. 물리 영역의 균일 배경 원에서 Fourier–Hankel 전개로 추출합니다. 원이 재료 또는 PML과 겹치면 거부합니다. 일반 문제에는 retained order와 추출 반경 수렴도 필요합니다.
- `save_npz`: 메시, 영역, scalar 계수, quadrature 굴절률/좌표/가중치, 필드 종류, 포트 β/벡터, S를 저장합니다. `allow_pickle=False`로 읽습니다.

## 검증 기록

최초 M3 테스트 20개와 독립 oracle을 솔버보다 먼저 작성·실행했습니다. oracle 2개 통과, 모듈 부재 18개 실패를 보존했습니다. 최초 파일 해시는 `results/m3_tests_before_solver.sha256`입니다.

초기 구현은 19개 통과, TM 슬랩 위상 테스트 1개 실패였습니다. 간격을 절반으로 줄이자 S21 오차는 0.00421623009에서 0.00105604968로 감소했습니다. 직사각형 좌표 간격을 h/2에서 h/3으로 세분화하여 해결했고 원래 테스트와 허용오차는 변경하지 않았습니다.

대규모 그림의 점 탐색에서 13.1 GiB 임시 배열을 요구한 실패는 matplotlib 삼각형 탐색과 P1 barycentric 보간으로 수정했습니다. 121×121 격자의 선형 함수 재현 테스트를 추가했습니다. CLI JSON에서 NumPy 정수 직렬화 오류는 diagnostics를 Python 정수로 반환하도록 수정하고 JSON 테스트를 추가했습니다. 로그는 results에 있습니다.

## 검증된 범위

PEC 직사각형 TE/TM 포트의 직선 전파, 유전체 층, 비대칭 인터페이스, 복소 S, 소멸 모드 DtN, 수동 흡수, 다중 모드 전력 보존과 상호성을 검증했습니다. 유한 창 슬랩의 기본 모드를 독립 분산식과 대조했습니다. PML은 종단 반사 해석식과 원통 Bessel–Hankel 급수의 정면/경사 입사, 실수/흡수 굴절률에 대해 검증했습니다.

## 검증되지 않은 범위

개방 광도파관의 PML 횡방향 모드 포트, 임의 벤드·테이퍼·격자의 정량 정확도, 금속/음의 유전율, 큰 전기적 크기, 실제 측정 분산 재료, M2 모드와 3D 포트 결합, 상용 프로그램 대조는 검증하지 않았습니다. 복잡한 구조의 필드 정확도는 전력 보존만으로 보장되지 않습니다.

## 알려진 한계

2D scalar 분리는 z 불변·등방성·비자성 조건에 한정됩니다. 포트는 수직이고 벽은 수평이며, 포트 인접 영역은 전파 방향으로 균일해야 합니다. callable만으로 마지막 조건을 자동 증명하지 않습니다. 횡방향 PML 포트는 지원하지 않습니다. 슬랩 포트는 유한 창 PEC 근사입니다. 짧은 파장과 긴 전파거리에는 P1 수치 분산으로 추가 세분화가 필요합니다. cutoff의 전력 정규화는 정의되지 않으며 지원하지 않습니다. 전파 모드가 없으면 입사를 거부합니다. gmsh와 희소 LU는 단일 프로세스이고 전체 S는 입사 채널마다 재조립합니다. CLI는 예제 구조용이며 CAD GUI는 없습니다.

## 기술 출처

- DOLFINx 0.9.0 공식 PML/원통 예제: https://docs.fenicsproject.org/dolfinx/v0.9.0/python/demos/demo_pml.html
- oomph-lib 공식 Helmholtz PML: https://oomph-lib.github.io/oomph-lib/doc/pml_helmholtz/scattering/html/index.html
- Orlandini et al. 포트 연구 arXiv 2407.21766: https://arxiv.org/html/2407.21766v1

참조 예제의 시간 부호를 그대로 복사하지 않았습니다. 본 코드의 e^{-iωt}는 outgoing Hankel(1)과 양의 허수 좌표 신장을 사용합니다. 독립 oracle은 연속 경계조건에서 유도했으며 FEM 출력을 기준값으로 사용하지 않습니다.
