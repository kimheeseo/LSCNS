# Python Wave Optics M2

M1 슬랩 솔버를 포함한 2D 전벡터 광학 모드 FEM 패키지. Python 3.11,
NumPy, SciPy, gmsh, scikit-fem, matplotlib를 사용한다. M3 산란/PML/포트는 포함하지 않는다.

## 설치 및 실행

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -e '.[test]'
pytest -q
python validate_m2.py
vector-modes fiber --wavelength 1 --n-core 1.5 --n-clad 1 \
  --core-radius 0.3 --outer-radius 3 --h 0.015 --target 1.25 \
  --window 1.0001 1.4999 --candidates 8 --output fiber_results
vector-modes rectangle --wavelength 1.55 --n-core 1.5+0.001j \
  --width 1.2 --height 0.9 --h 0.03 --target 1.4 \
  --window 0.85 1.5 --candidates 10 --output rectangle_loss_results
```

Linux의 gmsh 공유 라이브러리에는 배포판에 따라 libGLU/libXft가 필요하다.
이 실행 환경에서는 libXft 패키지를 비관리자 경로에 풀고 LD_LIBRARY_PATH로 지정했다.
일반 설치 시에는 배포판의 `libglu1-mesa`, `libxft2`를 설치할 수 있다.
실행 환경의 숫자와 버전은 `results/validation_m2.json`에 기록되어 있다.

## API

```python
import numpy as np
from waveoptics.vector import fiber_mesh, solve_vector

geometry = fiber_mesh(core_radius_um=.3, outer_radius_um=3., h_um=.015)
n = np.where(geometry.region == 1, 1.5, 1.)  # 정확한 CAD 영역 라벨
solution = solve_vector(geometry, n, wavelength_um=1., target_neff=1.25,
                        neff_window=(1.0001,1.4999), candidates=8)
for mode in solution.modes:
    print(mode.neff, mode.effective_area_um2, mode.loss_db_per_m)
    xy, weights, E, Z0H = solution.quadrature_fields(mode)
    # E.shape == Z0H.shape == (3,N); xy.shape == (2,N)
solution.save_npz('fields.npz')
```

`geometry`는 `VectorMesh` 또는 `skfem.MeshTri`이다. 임의 삼각형 메시와
임의 분포를 직접 입력할 수 있다. `n`은 스칼라, 삼각형별 배열 또는 callable이다.
callable에는 `(2, 요소 수, 구적점 수)` 좌표가 전달되고 결과는 해당 구적점 모양에
broadcast되어야 한다. 예: `lambda x: 1.45 + .02*np.exp(-(x[0]**2+x[1]**2))`.
불연속 매질은 인터페이스 정합 메시와 요소별 값을 권장한다. 미정합 callable의
불연속 경계는 정확하게 표현되지 않으며, 별도의 수렴 검증이 필요하다.

복소 굴절률은 `Re(n)>0, Im(n)>=0`이다. 이는 `exp(i beta z-i omega t)`에서 수동 흡수에
해당한다. 이득, 이방성, 자기 매질은 지원하지 않는다.

## 정식화

`E=(e_t, -i beta phi)`에서 `e_t`는 최저차 삼각형 Nédélec 엣지 요소,
`phi`는 P1 Lagrange 요소이다. 테스트 공간은 H0(curl) × H0¹이다.

\[
a=\int (\mathrm{curl}_t e_t)\overline{\mathrm{curl}_t v_t}
-k_0^2\epsilon_r e_t\cdot\overline{v_t},\qquad
b=\int(e_t+\nabla\phi)\cdot(\overline{v_t}+\nabla\overline\psi)
-k_0^2\epsilon_r\phi\overline\psi,\quad a=-\beta^2 b.
\]

PEC 외곽: 접선 전기장과 종방향 전기장이 0. 광섬유는 외곽을 멀리 배치한다.
물리적 PEC 도파관과 열린 광섬유의 영역 절단을 구분해야 한다.
행렬 A는 종방향 영 블록을, B는 부정정 구조를 갖는다. 따라서
`eigs(A, M=B)`처럼 양정정 질량 가정을 사용하는 경로를 피하고,
`(A-sigma B)^(-1) B`의 일반 고유치 문제를 `splu` 및 `eigs`로 푼다.
스펙트럼은 대상 근처의 `candidates`개만 탐색하며, 필터링된 창 전체의
모드 완전성을 보장하지 않는다. 실제 수치 잔차를 검사하고 반환·거절 기록을 제공한다.

Gauss 제약은 이산 시험함수에 대해
`G_epsilon.T @ e_t = beta**2 * Q_epsilon @ phi`로 평가한다.
모든 공간점에서의 강형식 발산이 0이라는 뜻은 아니다.
호환 gradient 공간의 curl-free 성질과 해석적 모드 수를 별도로 테스트한다.

## 출력 정의

- `neff=beta/k0`는 복소수이며, 모든 길이는 μm이다.
- `loss_db_per_m=(20/log(10))*Im(beta_per_um)*1e6`는 전력 감쇠 dB/m이다.
- `effective_area_um2=(integral |E|² dA)² / integral |E|⁴ dA`는 전기장 기준 면적이다.
  에너지/포인팅/Kerr 가중 면적과 같은 정의라고 가정하지 않는다.
- 필드는 `integral |E|² dA=1`로 정규화되며, 1 W 또는 절대 V/m가 아니다.
- `quadrature_fields`는 전기장과 `Z0*H=curl_beta(E)/(i*k0)`를 반환한다.
- `sample_electric`은 내부점 전기장을 보간한다. 재료 경계의 법선 성분은
  불연속이므로 경계에서 한쪽 값을 결정하는 평가로 사용하지 않는다.
- NPZ는 원본 메시 및 엣지/P1 계수를 보존한다. PNG의 셀 평균 시각화는
  계산된 구적점장으로부터 만들어지며, 평균장이 솔버의 장을 대체하지 않는다.

## 검증 및 재현

`tests/analytic_vector.py`의 특성방정식은 FEM 모듈을 import하지 않는다.
직사각형 해석식, 완전 벡터 Bessel 근, 해석장의 독립 적분이 기준이다.
초기 M2 테스트 20개는 솔버 전에 작성·실행되었다: 2개 통과, 모듈 미존재로 18개 실패.
초기 파일 해시는 `results/test_contract_sha256.txt`에 보존된다.
추가 검증은 흡수 광섬유의 복소 해석근, gradient 호환성, 출력 및 유한 원형 PEC
경계 해석근을 검사한다. M1의 기존 32개 테스트도 그대로 포함한다.

메시 세분화는 직사각형 h=0.12, 0.06, 0.03 μm, 광섬유 h=0.06, 0.03, 0.015 μm로
수행한다. 직사각형의 h는 지름 상한이며 실제 지름은 더 작다. 광섬유의 h는
gmsh 목표 크기이며 최대 엣지 길이와 다르다. 수렴표는 실제 최대 엣지 길이도 보고한다.
광섬유에는 코어 크기와 외곽 성장 크기를 함께 기록한다. 곡선은 직선 삼각형으로
표현하므로 고유치 오차는 요소 오차와 원 경계의 다각형 근사 오차를 포함한다.

`M2_VALIDATION_REPORT.md` 및 별도 Word 결과보고서에 실제 계산값, 실패 분석,
검증된 범위/검증되지 않은 범위/알려진 한계를 정리한다. 방사 손실, PML, 포트,
S-파라미터, M3 및 M4는 이 버전에서 구현·검증하지 않았다.

## 독립 자료

- FEniCS/DOLFINx 공식 혼합 모드 정식화:
  https://docs.fenicsproject.org/dolfinx/v0.9.0/python/demos/demo_half_loaded_waveguide.html
- 연구 구현자의 벡터 step-index 특성방정식:
  https://jayggg.github.io/fibermode/1_4_stepindex_vector.html

본 구현은 공식 예제의 코드를 복사한 것이 아니라 위 약형식을 scikit-fem으로 조립한다.
