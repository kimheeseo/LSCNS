# Python Wave Optics M4

Supplementary screenshot criteria: [PHOTO_VALIDATION_REPORT.md](PHOTO_VALIDATION_REPORT.md). The original 104 tests passed in two disjoint executions; an additional 9 data acceptance tests passed after actual supplementary measurements. The 3D spherical Mie benchmark and independent human/model review remain unverified. Run `python audit/measure_photo.py`, `python audit/refine_photo.py`, then `pytest audit/test_photo_criteria.py -q` to regenerate the supplementary checks.

M1 1D slab modes, M2 compatible 2D vector modes, M3 2D TE/TM scattering, and M4 3D frequency-domain Maxwell FEM. Python 3.11; gmsh 4.14.1, NumPy 2.2.6, SciPy 1.15.3, scikit-fem 12.0.2, matplotlib 3.10.3. All lengths in micrometres; exp(-i omega t).

## Installation and execution

```bash
python3.11 -m venv .venv
. .venv/bin/activate
python -m pip install -e '.[test]'
OPENBLAS_NUM_THREADS=1 pytest -q
OPENBLAS_NUM_THREADS=1 python validate_m4.py
maxwell-3d --case straight --mode TE10 --h .1 --out demo_straight
maxwell-3d --case layer --mode TM11 --layer-index 1.6+0.03j --h .1 --full-s --out demo_layer
maxwell-3d --case pml --mode TE10 --h .1 --pml-strength 4 --out demo_pml
```

Linux gmsh shared-library prerequisite typically requires `libglu1-mesa` and `libxft2`. This task runtime used a recorded local LD_LIBRARY_PATH; portable users should install OS libraries rather than copy the runtime-specific path. 3D fine meshes require substantial memory and sparse direct factorization time; run numerical validations serially. Timing is not a benchmark.

## 3D API

```python
from waveoptics.maxwell3d import box_mesh, RectangularMode, solve_guide, solve_s_matrix
geo = box_mesh([0,.8], [0,.6], [0,.5], h_um=.1)
solution = solve_guide(geo, wavelength_um=1., index=1.2,
    incident_mode=RectangularMode('TE',1,0), max_orders=(2,2))
print(solution.S[('right','TE',1,0)])
x, weights, E, H = solution.quadrature_fields()
solution.save_npz('field.npz')
S, channels = solve_s_matrix(geo,1.,1.2)
```

`solve_pec(geo,wavelength,index,source)` solves an impressed right-hand side `f` in curlcurl E-k0^2 n^2 E=f with PEC on all faces. `index` is a scalar or callable accepting plain NumPy coordinates; positive real part and nonnegative imaginary part only. Callable guides require explicit real `port_indices=(n_left,n_right)`. Mesh breaks align index interfaces; resolving a discontinuity inside a tetrahedron is the caller's responsibility. API geometry accepts VolumeMesh built from an appropriate MeshTet, but built-in meshing is a partitioned box.

`CartesianPML(physical_bounds,thickness,strength=4,power=2)` accepts three increasing axis intervals and three (lower,upper) thickness pairs. `solve_guide(...,ports=('left',),pml=...)` supports longitudinal PML on the opposite end, truncated by PEC. The tensor kernel implements all axes and corners. PML matching is validated for continuation of a longitudinally uniform guide; the caller must ensure the material is continued appropriately through the PML. Accuracy for general open 3D radiation with six-face PML is NOT established by the present guide tests. A general plane-wave open-space scatterer and Mie-sphere benchmark are not included.

## Mathematical interpretation

Read M4_FORMULATION.md before use. Nedelec tetrahedral edge coefficients are oriented line integrals, not nodal electric vectors. Compatible grad(P1) subset N1 is checked using edge-node incidence; no arbitrary vector nodal discretization or beta-eigenmode spectrum is claimed. Passive isotropic nonmagnetic material. Physical H=curl E/(i k0 Z0); in PML the returned H is transformed using mu_PML^-1. PML E/H are computational covectors, not physical-space fields. All public coordinates and callback arrays are plain NumPy arrays.

Rectangular ports use normalized analytic TE/TM transverse E fields on x,y and propagation z. TE means E_z=0, TM means H_z=0; this differs from M3's out-of-plane polarization labels. Finite retained modal trace span uses Nedelec edge interpolation, PEC on the perimeter, and analytic radiation gamma_TE=beta, gamma_TM=k0^2 n_port^2/beta. Consistent facet overlap C=int e_m dot Pi_h e_j is used in the port matrix -i C^T Gamma C, incoming load and outgoing physical coefficients c=C u_port; interpolation does not preserve exact analytic orthogonality. Volume quadrature is degree 7 with 24 positive strictly interior points; port overlap uses degree 8 facet quadrature. Both evanescent and propagating modes with indices up to max_orders are included. Unretained trace modes are set to zero. This is a truncated modal boundary, NOT a complete discrete trace DtN. Change mesh and max_orders independently; a uniform-guide cutoff stability check does not guarantee general-device accuracy.

Port index is real, positive and uniform; adjacent guide must be longitudinally uniform. Solver checks one very near-port plane for declared n consistency, not the required extent of the uniform lead. Material is arbitrary 3D within the box, and fully 3D patch conversion is structurally checked, not benchmarked for quantitative accuracy. Complex incident/lossy ports, cutoff and open dielectric fiber port modes are unsupported. Incident transverse modal coefficient=1; fields are not normalized to 1 W. For retained propagating channels S uses sqrt(real gamma_out/real gamma_in). S reference phases include distances between outer z-port planes. Port coefficients and field amplitudes have the normalization in M4_FORMULATION.md; no absolute-watt claim.

## Verification artifacts

Independent analytic oracles in tests/analytic_maxwell3d.py import no solver. Initial test file and oracle were created and run before solver; original SHA hashes remain unchanged. Results include initial failures, diagnoses, final pytest XML/logs, JSON and CSV three-grid numbers, coefficient NPZs, convergence and field plots. NPZ field_kind='total'; computational PML domains and physical bounds are saved. Compressed field plotting data are cell-volume-average samples on a near y=.3 slice, not a nodal interpolation or an exact geometric section.

Validated scopes: PEC manufactured 3D vector field; uniform TE10/TM11 vector fields and complex S; real/absorbing transverse-uniform layers; analytic PML termination reflection; finite trace order change for uniform TE10; all-channel reciprocity/unitarity and nonzero TE/TM conversion in a 3D patch; compatible sequence, positive quadrature, E/H formulas, NPZ and CLI; M1-M3 regression.
Unverified scopes: open 3D dielectric-fiber ports and leakage; free-space sphere/Mie scattering; numerical accuracy of arbitrary bends/tapers/multimode patches; anisotropy, magnetic/negative-epsilon metals; gain; resonance/high-frequency scalability; fabrication or commercial-fiber comparison.
Known limits: first-order edge field O(h), complex S orders are measured per benchmark and are not guaranteed for general geometry; finite modal trace truncation; finite PML/reflection floor; PEC box benchmark is not a real optical fiber; sparse single-process LU and gmsh, no MPI/GUI/CAD importer; derivative H piecewise constant in each physical tetrahedron. Matrix residual, weak Gauss, reciprocity and unitarity do not replace independent field-error tests.

Sources: Monk & Zhang (2019) https://arxiv.org/abs/1910.10069 ; scikit-fem official API https://scikit-fem.readthedocs.io/en/latest/api.html ; DOLFINx Maxwell/PML https://docs.fenicsproject.org/dolfinx/v0.9.0/python/demos/demo_pml.html ; COMSOL rectangular-waveguide model https://doc.comsol.com/6.4/doc/com.comsol.help.models.rf.waveguide_adapter/waveguide_adapter.html . Our exp(-i omega t) convention uses positive imaginary stretch; do not transplant opposite-time-convention PML signs.

Built-in box meshing uses conforming structured gmsh tetrahedral extrusion, coordinate spacing <= h_um/sqrt(3). Actual maximum tetrahedral edge length h_max_um is measured. Sparse LU uses geometric nested dissection structural separators and leaf RCM ordering, with the default numerical pivot threshold 1. An HXT alternative reduced meshing cost but failed the original coarse-grid TE convergence-slope contract and was rejected; all frozen tolerances remain unchanged.

The recorded validation uses disjoint pytest runs: 12 original M4 core cases (pytest_nested.xml) and 92 regression/additional cases (pytest_regression.xml). pytest_final.xml is an explicitly labelled aggregate, not a single-process raw run. Raw stdout and source XML remain authoritative. Users can run all cases with pytest -q. The 22 legacy warnings comprise 8 finite-cladding truncation notices and 14 matplotlib/pyparsing deprecation occurrences.

Exact recorded test selections and raw measurement collection:
```bash
OPENBLAS_NUM_THREADS=1 pytest -q tests/test_maxwell3d_m4.py --junitxml=results/pytest_nested.xml
OPENBLAS_NUM_THREADS=1 pytest -q --ignore=tests/test_maxwell3d_m4.py --junitxml=results/pytest_regression.xml -o junit_logging=all -o junit_log_passing_tests=true
python aggregate_verification.py
OPENBLAS_NUM_THREADS=1 python validate_m4.py
```
The additional TE10 H test retains its 1e-13 formula-consistency check and independently compares all H components to closed TE10 fields on three meshes. validation_H.json comes from its captured JUnit stdout; no solver-derived reference is used.
