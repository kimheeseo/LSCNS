from pathlib import Path
import xml.etree.ElementTree as ET
import json,copy,hashlib
r=Path(__file__).parent/'results'
files=['pytest_nested.xml','pytest_regression.xml'];sources=[];cases=[]
for name in files:
 s=ET.parse(r/name).getroot().find('testsuite')
 assert all(int(s.attrib[k])==0 for k in ['failures','errors','skipped'])
 cc=list(s.findall('testcase'));assert len(cc)==int(s.attrib['tests']);cases+=cc
 sources.append(dict(file=name,sha256=hashlib.sha256((r/name).read_bytes()).hexdigest(),**s.attrib))
keys=[(c.attrib['classname'],c.attrib['name']) for c in cases];assert len(set(keys))==len(cases)==104
root=ET.Element('testsuites');suite=ET.SubElement(root,'testsuite',name='explicit_aggregate_of_two_disjoint_pytest_runs',tests=str(len(cases)),errors='0',failures='0',skipped='0',time=str(sum(float(s['time']) for s in sources)))
props=ET.SubElement(suite,'properties');ET.SubElement(props,'property',name='provenance',value='Derived aggregate; raw source XML and stdout are authoritative. Not a single-process run.')
for c in cases:suite.append(copy.deepcopy(c))
ET.ElementTree(root).write(r/'pytest_final.xml',encoding='utf-8',xml_declaration=True)
(r/'pytest_aggregate_provenance.json').write_text(json.dumps(dict(total_tests=104,disjoint=True,single_process=False,sources=sources),indent=2)+'\n')
(r/'pytest_final.log').write_text('EXPLICIT AGGREGATE OF DISJOINT RUNS\n'+''.join(f"{s['file']}: {s['tests']} passed, {s['time']} s\n" for s in sources)+'104 passed total; raw source stdout/XML preserved.\n')
print((r/'pytest_final.log').read_text())

# Independent H measurements captured from the passing analytic pytest.
c=next(c for c in cases if c.attrib['name']=='test_curl_field_and_units')
msg=c.find('system-out').text
h=json.JSONDecoder().raw_decode(msg.split('M4_H_ANALYTIC_ROWS=',1)[1])[0]
(r/'validation_H.json').write_text(json.dumps(h,indent=2)+'\n')
