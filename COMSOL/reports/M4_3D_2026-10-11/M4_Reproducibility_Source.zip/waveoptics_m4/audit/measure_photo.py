"""Re-execute independent-reference screenshot checks; no tolerance fitting."""
import sys,json,time,gc,hashlib
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import scipy,skfem,gmsh
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'tests'))
from analytic_slab import exact_modes
from analytic_vector import FiberReference
from analytic_scattering import layer_s,cylinder_width
from analytic_maxwell3d import params,vector_field,pml_reflection
from waveoptics.slab import solve_slab
from waveoptics.vector import fiber_mesh,solve_vector
from waveoptics.scattering import guide_mesh,solve_ports,cylinder_mesh,solve_plane_wave,PML
from waveoptics.maxwell3d import box_mesh,solve_guide,CartesianPML,RectangularMode
import repository_cavity
t0=time.monotonic()
d=dict(executed_utc=datetime.now(timezone.utc).isoformat(),python=sys.version.split()[0],versions=dict(numpy=np.__version__,scipy=scipy.__version__,skfem=skfem.__version__,gmsh=gmsh.__version__),slab={},fiber=[],layers=[],cylinder=[],cavity={},new_wavelength={},pml={})
def json_default(v):
 if isinstance(v,np.ndarray):return v.tolist()
 if isinstance(v,np.generic):return v.item()
 if isinstance(v,complex):return [v.real,v.imag]
 raise TypeError(type(v).__name__)
def ck(label):
 (HERE/'photo_validation.checkpoint.json').write_text(json.dumps(d,indent=2,default=json_default)+'\n');print(label,flush=True)
def slopes(rows,key):
 return (np.log(np.array([r[key] for r in rows[:-1]])/np.array([r[key] for r in rows[1:]]))/np.log(np.array([r['h_max_um'] for r in rows[:-1]])/np.array([r['h_max_um'] for r in rows[1:]]))).tolist()
def z(v):return [float(v.real),float(v.imag)]
for pol in ['TE','TM']:
 refs=exact_modes(1.5,1.45,3.,1.55,pol);rows=[]
 for h in [.075,.0375,.01875]:
  s=solve_slab(n_core=1.5,n_clad=1.45,width_um=3.,wavelength_um=1.55,padding_um=20.,max_modes=6,polarization=pol,h_um=h)
  e=[abs(m.neff-r.neff)/r.neff for m,r in zip(s.modes,refs)]
  rows.append(dict(h_max_um=s.h_max_um,neff=[m.neff for m in s.modes],exact_neff=[r.neff for r in refs],relative_errors=e,error=max(e)))
 d['slab'][pol]=dict(rows=rows,slopes=slopes(rows,'error'));ck('slab '+pol)
ref=FiberReference()
for h in [.04,.02,.01]:
 g=fiber_mesh(.3,3.,h,outer_factor=5.)
 s=solve_vector(g,np.where(g.region==1,1.5,1.),wavelength_um=1.,target_neff=1.25,neff_window=(1.0001,1.4999),candidates=8)
 d['fiber'].append(dict(h_nominal_um=h,h_max_um=s.diagnostics['h_core_max_um'],neff=[z(m.neff) for m in s.modes],exact_neff=ref.neff,worst_absolute_error=max(abs(m.neff-ref.neff) for m in s.modes),max_gauss_residual=max(m.gauss_residual for m in s.modes),**{'diagnostics':s.diagnostics}));ck('fiber '+str(h));s=None;gc.collect()
for pol in ['TE','TM']:
 for case in ['layer','asymmetric','absorbing']:
  if case=='asymmetric':
   ns=[1.2,1.6];ls=[.4,.5];breaks=[0,.4,.9];idx=lambda x:np.where(x[0]<.4,1.2,1.6)
  else:
   middle=1.6+(0.03j if case=='absorbing' else 0j);ns=[1.2,middle,1.2];ls=[.3,.25,.35];breaks=[0,.3,.55,.9];idx=lambda x:np.where((x[0]>.3)&(x[0]<.55),middle,1.2)
  s=solve_ports(guide_mesh(breaks,[0,.6],.02),idx,1.,pol);r,t=layer_s(ns,ls,1.,.6,1 if pol=='TE' else 0,pol)
  R=sum(abs(v)**2 for v in s.s_parameters['left']);T=sum(abs(v)**2 for v in s.s_parameters['right'])
  d['layers'].append(dict(polarization=pol,case=case,R=float(R),T=float(T),exact_R=abs(r)**2,exact_T=abs(t)**2,error_R=abs(R-abs(r)**2),error_T=abs(T-abs(t)**2),**s.diagnostics));ck('layer '+pol+' '+case)
for pol in ['TE','TM']:
 p=PML((-.8,.8),(-.8,.8),left=.6,right=.6,bottom=.6,top=.6,strength=4.)
 s=solve_plane_wave(cylinder_mesh(.2,p,.02),1.5,1.,1.,pol,pml=p)
 width=s.scattering_width(.55,orders=8);exact=cylinder_width(.2,1.5,1.,1.,pol)
 d['cylinder'].append(dict(polarization=pol,width_um=width,exact_width_um=exact,relative_width_error=abs(width/exact-1),**s.diagnostics));ck('cylinder '+pol);s=None;gc.collect()
old=json.loads((HERE/'previous_m3_validation.json').read_text())
d['previous_cylinder_three_meshes']=old['cylinder']
d['fiber_slopes']=slopes(d['fiber'],'worst_absolute_error')
cav=[]
for shape in [(4,3,6),(8,6,12),(16,12,24)]:
 info,mesh=repository_cavity.solve(shape=shape)
 xyz,tets,edges,mode=mesh
 hmax=max(np.linalg.norm(xyz[tets[:,i]]-xyz[tets[:,j]],axis=1).max() for i in range(4) for j in range(i))
 info['h_max_um']=float(hmax);cav.append(info);d['cavity']['rows']=cav;ck('cavity '+str(shape));mesh=None;gc.collect()
d['cavity']['slopes']=slopes(cav,'relative_error')
d['cavity']['oracle_formula']='c0/(2*n*1e-6)*sqrt(1/a_um**2+1/c_um**2)'
d['cavity']['source_sha256']=hashlib.sha256((HERE/'repository_cavity.py').read_bytes()).hexdigest()
wl=1.13;rows=[]
for h in [.2,.1,.05]:
 s=solve_guide(box_mesh([0,.8],[0,.6],[0,.5],h),wl,1.2,RectangularMode('TE',1,0))
 beta=params('TE',1,0,.8,.6,1.2,wl)[1];exact=np.exp(1j*beta*.5)
 rows.append(dict(wavelength_um=wl,S21=z(s.S[('right','TE',1,0)]),exact_S21=z(exact),S21_error=abs(s.S[('right','TE',1,0)]-exact),field_error=s.field_error(lambda x:vector_field(x,'TE',1,0,.8,.6,1.2,wl)),**s.diagnostics))
 d['new_wavelength']['rows']=rows;ck('new wavelength '+str(h));s=None;gc.collect()
d['new_wavelength']['slopes']=slopes(rows,'S21_error')
rows=[];cor=[]
for t,r in [(.2,1),(.3,2),(.4,3)]:
 p=CartesianPML(((0,.8),(0,.6),(0,.5)),((0,0),(0,0),(0,t)),strength=4,power=r)
 s=solve_guide(box_mesh([0,.8],[0,.6],[0,.5,.5+t],.08),1.,1.2,RectangularMode('TE',1,0),ports=('left',),pml=p)
 value=s.S[('left','TE',1,0)];beta=params('TE',1,0,.8,.6,1.2,1.)[1];exact=pml_reflection(beta,.5+t,t,4,r);cor.append(value-exact)
 rows.append(dict(thickness_um=t,power=r,amplitude=abs(value),complex_error=abs(value-exact),S11=z(value),exact_S11=z(exact),**s.diagnostics));d['pml']['rows']=rows;ck('PML '+str((t,r)));s=None;gc.collect()
d['pml']['corrected_max_difference']=float(max(abs(a-b) for a in cor for b in cor))
# Independent analytic transverse modes compared with production trace modes.
q,w=np.polynomial.legendre.leggauss(48);x,y=np.meshgrid((q+1)*.4,(q+1)*.3,indexing='ij');ww=(w[:,None]*w[None,:]*.12).ravel();xyz=np.array([x.ravel(),y.ravel(),np.zeros(x.size)])
keys=[('TE',0,1),('TE',1,0),('TE',1,1),('TM',1,1)]
F=np.array([vector_field(xyz,*k,.8,.6,1.2,1.)[:2].real for k in keys])
G=np.array([RectangularMode(*k).transverse(xyz,np.array([[0,.8],[0,.6],[0,.5]]))[:2] for k in keys])
gram=np.einsum('icq,jcq,q->ij',F,G,ww)
d['port_orthogonality_error']=float(np.linalg.norm(gram-np.eye(len(keys))))
d['port_orthogonality_gram']=gram.tolist()
main=json.loads((ROOT/'results/validation_m4.json').read_text());d['reciprocity_residual']=main['mode_conversion']['reciprocity_residual'];d['reciprocity_source']='results/validation_m4.json: actual previous 8x8 solve'
d['elapsed_seconds']=time.monotonic()-t0
(HERE/'photo_validation.json').write_text(json.dumps(d,indent=2,default=json_default)+'\n');ck('complete')
