"""Keep failed measurements, refine mesh, and measure physical absorption."""
import sys,json,time
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'tests'))
from analytic_scattering import cylinder_width
from waveoptics.scattering import cylinder_mesh,solve_plane_wave,PML,guide_mesh,solve_ports
p=HERE/'photo_validation.json';d=json.loads(p.read_text())
(HERE/'photo_validation_initial.json').write_bytes(p.read_bytes())
t0=time.monotonic();d['cylinder_initial']=d['cylinder'].copy()
pol='TM';pml=PML((-.8,.8),(-.8,.8),left=.6,right=.6,bottom=.6,top=.6,strength=4.)
s=solve_plane_wave(cylinder_mesh(.2,pml,.01),1.5,1.,1.,pol,pml=pml)
width=s.scattering_width(.55,orders=8);exact=cylinder_width(.2,1.5,1.,1.,pol)
row=dict(polarization=pol,width_um=width,exact_width_um=exact,relative_width_error=abs(width/exact-1),**s.diagnostics)
d['cylinder']=[r for r in d['cylinder'] if r['polarization']!='TM']+[row]
print('TM refined',row,flush=True)
d['volume_absorption']=[]
for pol in ['TE','TM']:
 idx=lambda x:np.where((x[0]>.3)&(x[0]<.55),1.6+.03j,1.2)
 s=solve_ports(guide_mesh([0,.3,.55,.9],[0,.6],.02),idx,1.,pol)
 f=s.basis.interpolate(s.field);nv=s.quadrature_index;weights=s.basis.dx
 beta=s.port_modes['left'].beta[s.port_modes['left'].propagating[0]].real
 integrand=(2*np.pi)**2*np.imag(nv**2)*abs(f)**2 if pol=='TE' else -np.imag(nv**-2)*np.sum(abs(f.grad)**2,axis=0)
 A=float(np.sum(weights*integrand)/beta)
 R=float(np.sum(abs(s.s_parameters['left'])**2));T=float(np.sum(abs(s.s_parameters['right'])**2))
 r=dict(polarization=pol,A_volume=A,R=R,T=T,energy_residual=abs(R+T+A-1),h_max_um=s.diagnostics['h_max_um'])
 d['volume_absorption'].append(r);print('energy',r,flush=True)
d['refinement_and_energy_elapsed_seconds']=time.monotonic()-t0
p.write_text(json.dumps(d,indent=2)+'\n')
