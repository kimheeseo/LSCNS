"""Screenshot contract, written before the supplementary measurements."""
import json
from pathlib import Path
import numpy as np
import pytest

@pytest.fixture(scope='module')
def data():
    return json.loads((Path(__file__).parent/'photo_validation.json').read_text())

def test_slab_relative_neff(data):
    for p in ['TE','TM']:
        a=data['slab'][p]
        assert all(len(r['neff'])==len(r['exact_neff'])==2 for r in a['rows'])
        assert max(a['rows'][-1]['relative_errors'])<1e-6
        assert np.all((np.array(a['slopes'])>1.8)&(np.array(a['slopes'])<2.2))

def test_fiber_exact_vector(data):
    assert all(len(r['neff'])==2 for r in data['fiber'])
    e=np.array([r['worst_absolute_error'] for r in data['fiber']])
    assert e[-1]<1e-4 and np.all(np.diff(e)<0)

def test_RT_power_against_TMM(data):
    assert max(max(r['error_R'],r['error_T']) for r in data['layers'])<1e-3

def test_cylinder_scattering_width(data):
    assert max(r['relative_width_error'] for r in data['cylinder'])<.01

def test_cavity_frequency(data):
    assert data['cavity']['rows'][-1]['relative_error']<.001
    p=np.array(data['cavity']['slopes']);assert np.all((p>1.5)&(p<2.5))

def test_new_wavelength(data):
    a=data['new_wavelength'];assert a['rows'][-1]['S21_error']<.01
    assert a['rows'][-1]['field_error']<.13
    p=np.array(a['slopes']);assert np.all((p>1.3)&(p<2.7))

def test_PML_thickness_profile(data):
    a=data['pml'];assert max(r['amplitude'] for r in a['rows'])<.02
    assert max(r['complex_error'] for r in a['rows'])<.025
    assert a['corrected_max_difference']<.015

def test_reciprocity_and_port_orthogonality(data):
    assert data['reciprocity_residual']<1e-9
    assert data['port_orthogonality_error']<1e-10

def test_volume_absorption_energy(data):
    for r in data['volume_absorption']:
        assert r['A_volume']>0
        assert r['energy_residual']<1e-9
