"""Independent continuous rectangular-guide and manufactured-field oracles.
No solver imports or numerical solver reference generation.
"""
import numpy as np

def params(kind,m,n,a,b,index,wavelength):
    kc2=(m*np.pi/a)**2+(n*np.pi/b)**2
    k2=(2*np.pi/wavelength*index)**2
    beta=np.sqrt(k2-kc2+0j)
    gamma=beta if kind=='TE' else k2/beta
    return kc2,beta,gamma

def vector_field(x,kind,m,n,a,b,index,wavelength,z_origin=0):
    kc2,beta,_=params(kind,m,n,a,b,index,wavelength)
    x0,y,z=x
    mx=m*np.pi/a;ny=n*np.pi/b
    norm=np.sqrt(kc2*a*b/(4 if m and n else 2))
    E=np.zeros_like(x,dtype=complex)
    if kind=='TE':
        E[0]=-ny*np.cos(mx*x0)*np.sin(ny*y)/norm
        E[1]=mx*np.sin(mx*x0)*np.cos(ny*y)/norm
    else:
        E[0]=mx*np.cos(mx*x0)*np.sin(ny*y)/norm
        E[1]=ny*np.sin(mx*x0)*np.cos(ny*y)/norm
        E[2]=-1j*kc2/beta*np.sin(mx*x0)*np.sin(ny*y)/norm
    return E*np.exp(1j*beta*(z-z_origin))[None,...]

def layer_rt(kind,m,n,a,b,indices,lengths,wavelength):
    _,_,y0=params(kind,m,n,a,b,indices[0],wavelength)
    _,_,y1=params(kind,m,n,a,b,indices[-1],wavelength)
    T=np.eye(2,dtype=complex)
    for index,length in zip(indices,lengths):
        _,beta,gamma=params(kind,m,n,a,b,index,wavelength)
        q=beta*length
        T=np.array([[np.cos(q),1j*np.sin(q)/gamma],[1j*gamma*np.sin(q),np.cos(q)]])@T
    # [t, y1*t] = T @ [1+r,y0*(1-r)]
    rhs=T@np.array([1,y0])
    mat=np.column_stack((-T@np.array([1,-y0]),np.array([1,y1])))
    r,t=np.linalg.solve(mat,rhs)
    return r,t*np.sqrt(y1.real/y0.real)

def pml_reflection(beta,length,thickness,strength,power):
    return -np.exp(2j*beta*(length+1j*strength*thickness/(power+1)))

def manufactured(x,b,c):
    E=np.zeros_like(x)
    E[0]=np.sin(np.pi*x[1]/b)*np.sin(np.pi*x[2]/c)
    return E
