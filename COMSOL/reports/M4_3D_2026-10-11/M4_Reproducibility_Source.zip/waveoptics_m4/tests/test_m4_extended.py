"""Additional feature checks; original analytic acceptance contract unchanged."""
import json
import numpy as np
import pytest
from scipy.constants import physical_constants
from waveoptics.maxwell3d import box_mesh,RectangularMode,CartesianPML,solve_guide,solve_s_matrix,solve_pec,Z0

def test_three_axis_pml_tensor():
    p=CartesianPML(((0,1),(0,2),(0,3)),((.2,.3),(.4,.5),(.6,.7)),strength=2,power=2)
    x=np.array([[-.1,1.15,.5],[-.2,2.25,1.],[ -.3,3.35,1.5]])
    s=np.array([[1+.5j,1+.5j,1],[1+.5j,1+.5j,1],[1+.5j,1+.5j,1]])
    assert np.max(abs(p.stretches(x)-s))<1e-14
    T=np.prod(s,axis=0)[None,:]/s**2
    assert np.max(abs(p.tensor(x)-T))<1e-14
    assert np.max(abs(np.prod(p.tensor(x),axis=0)-np.prod(s,axis=0)))<1e-14

def test_all_channel_unitarity_and_reciprocity():
    g=box_mesh([0,.4,.8],[0,.3,.6],[0,.15,.35,.5],.13)
    n=lambda x:np.where((x[0]>.4)&(x[1]>.3)&(x[2]>.15)&(x[2]<.35),1.6,1.2)
    S,channels=solve_s_matrix(g,1,n,port_indices=(1.2,1.2))
    assert S.shape==(8,8) and len(channels)==8
    assert np.linalg.norm(S-S.T)<1e-9
    assert np.linalg.norm(S.conj().T@S-np.eye(len(S)))<1e-9
    te=channels.index(('left','TE',1,0));tm=channels.index(('right','TM',1,1))
    assert abs(S[tm,te])>1e-4

def test_port_cutoff_stability_straight():
    g=box_mesh([0,.8],[0,.6],[0,.5],.1);mode=RectangularMode('TE',1,0)
    a=solve_guide(g,1,1.2,mode,max_orders=(2,2));b=solve_guide(g,1,1.2,mode,max_orders=(3,3))
    assert abs(a.S[('right','TE',1,0)]-b.S[('right','TE',1,0)])<.004
    json.dumps(b.diagnostics)

def test_curl_field_and_units():
    # Independent closed TE10 H, not solver curl as the accuracy reference.
    a,b,wl,n=.8,.6,1.,1.2;k0=2*np.pi/wl;mx=np.pi/a
    beta=np.sqrt((k0*n)**2-mx**2);normal=mx*np.sqrt(a*b/2)
    z0_ref=physical_constants["characteristic impedance of vacuum"][0]
    errors=[];hs=[];records=[]
    for h in [.2,.1,.05]:
        g=box_mesh([0,a],[0,b],[0,.5],h);s=solve_guide(g,wl,n,RectangularMode('TE',1,0))
        x,w,E,H=s.quadrature_fields();phase=np.exp(1j*beta*x[2])
        exact=np.zeros_like(x,dtype=complex)
        exact[0]=-beta/(k0*z0_ref)*mx/normal*np.sin(mx*x[0])*phase
        exact[2]=mx**2/(1j*k0*z0_ref*normal)*np.cos(mx*x[0])*phase
        errors.append(np.sqrt(np.sum(np.sum(abs(H-exact)**2,axis=0)*w)/np.sum(np.sum(abs(exact)**2,axis=0)*w)))
        hs.append(s.diagnostics['h_max_um'])
        records.append(dict(h_nominal_um=h,H_l2_error=float(errors[-1]),**s.diagnostics))
        formula=s.basis.interpolate(s.coefficients).curl/(1j*k0*Z0)
        assert np.max(abs(H-formula))<1e-13 and np.max(abs(E))>0
    p=np.log(np.array(errors[:-1])/errors[1:])/np.log(np.array(hs[:-1])/hs[1:])
    print("M4_H_ANALYTIC_ROWS="+json.dumps(dict(rows=records,H_slopes=p.tolist(),reference_Z0_ohm=z0_ref)))
    assert errors[-1]<.13
    assert np.all((p>.75)&(p<1.35))

def test_pml_port_rejections():
    g=box_mesh([0,.8],[0,.6],[0,.5],.2);m=RectangularMode('TE',1,0)
    p=CartesianPML(((0,.8),(0,.6),(0,.4)),((0,0),(0,0),(0,.1)))
    with pytest.raises(ValueError):solve_guide(g,1,1.2,m,pml=p)
    with pytest.raises(ValueError):solve_guide(g,1,lambda x:np.ones(x.shape[1:])*1.3,m,port_indices=(1.2,1.2))
    with pytest.raises(ValueError):solve_guide(g,1,1.2,m,max_orders=(12,12))
