import numpy as np
import pytest
from analytic_maxwell3d import params,vector_field,layer_rt,pml_reflection,manufactured

def api():
    from waveoptics.maxwell3d import box_mesh,RectangularMode,CartesianPML,solve_pec,solve_guide
    return box_mesh,RectangularMode,CartesianPML,solve_pec,solve_guide

def slopes(errors,hs):
    return np.log(np.array(errors[:-1])/errors[1:])/np.log(np.array(hs[:-1])/hs[1:])

def test_oracle_no_layer():
    for kind,m,n in [('TE',1,0),('TM',1,1)]:
        _,beta,_=params(kind,m,n,.8,.6,1.2,1)
        r,t=layer_rt(kind,m,n,.8,.6,[1.2]*3,[.1,.2,.2],1)
        assert abs(r)<1e-13
        assert abs(t-np.exp(1j*beta*.5))<1e-13

def test_manufactured_three_meshes():
    mesh,_,_,solve,_=api();errors=[];hs=[]
    for h in [.2,.1,.05]:
        geo=mesh([0,.7],[0,.6],[0,.5],h)
        E=lambda x:manufactured(x,.6,.5)
        alpha=np.pi**2*(1/.6**2+1/.5**2)-(2*np.pi/1.7*1.1)**2
        sol=solve(geo,1.7,1.1,lambda x:alpha*E(x))
        errors.append(sol.field_error(E));hs.append(sol.diagnostics['h_max_um'])
        assert sol.diagnostics['linear_residual']<1e-10
        assert sol.diagnostics['weak_gauss_residual']<1e-9
    assert errors[-1]<.10
    assert np.all((slopes(errors,hs)>.75)&(slopes(errors,hs)<1.35))

@pytest.mark.parametrize('kind,m,n',[('TE',1,0),('TM',1,1)])
def test_straight_three_meshes(kind,m,n):
    mesh,mode,_,_,solve=api();errors=[];hs=[]
    _,beta,_=params(kind,m,n,.8,.6,1.2,1)
    for h in [.2,.1,.05]:
        sol=solve(mesh([0,.8],[0,.6],[0,.5],h),1,1.2,mode(kind,m,n),max_orders=(2,2))
        errors.append(abs(sol.S[('right',kind,m,n)]-np.exp(1j*beta*.5)));hs.append(sol.diagnostics['h_max_um'])
        assert sol.diagnostics['linear_residual']<1e-10
        assert sol.diagnostics['weak_gauss_residual']<1e-9
    assert errors[-1]<.025
    assert abs(sol.S[('left',kind,m,n)])<.025
    assert sol.field_error(lambda x:vector_field(x,kind,m,n,.8,.6,1.2,1))<.13
    assert np.all((slopes(errors,hs)>1.4)&(slopes(errors,hs)<2.6))

@pytest.mark.parametrize('kind,m,n',[('TE',1,0),('TM',1,1)])
@pytest.mark.parametrize('loss',[0,.03])
def test_layer(kind,m,n,loss):
    mesh,mode,_,_,solve=api();indices=[1.2,1.6+1j*loss,1.2]
    index=lambda x:np.where((x[2]>.15)&(x[2]<.35),indices[1],indices[0])
    sol=solve(mesh([0,.8],[0,.6],[0,.15,.35,.5],.045),1,index,mode(kind,m,n),port_indices=(1.2,1.2),max_orders=(2,2))
    r,t=layer_rt(kind,m,n,.8,.6,indices,[.15,.2,.15],1)
    assert abs(sol.S[('left',kind,m,n)]-r)<.025
    assert abs(sol.S[('right',kind,m,n)]-t)<.025
    power=sum(abs(s)**2 for s in sol.S.values())
    if loss==0:assert abs(power-1)<1e-9
    else:assert 0<power<1 and abs(power-(abs(r)**2+abs(t)**2))<.015

@pytest.mark.parametrize('kind,m,n',[('TE',1,0),('TM',1,1)])
def test_pml_analytic_reflection(kind,m,n):
    mesh,mode,pml,_,solve=api();_,beta,_=params(kind,m,n,.8,.6,1.2,1)
    amplitudes=[]
    for strength in [0,1.2,4]:
        layer=pml(((0,.8),(0,.6),(0,.5)),((0,0),(0,0),(0,.3)),strength=strength)
        sol=solve(mesh([0,.8],[0,.6],[0,.5,.8],.05),1,1.2,mode(kind,m,n),max_orders=(2,2),ports=('left',),pml=layer)
        r=sol.S[('left',kind,m,n)]
        assert abs(r-pml_reflection(beta,.8,.3,strength,2))<.025
        amplitudes.append(abs(r))
    assert amplitudes[2]<amplitudes[1]<amplitudes[0]


def test_sequence_and_serialization(tmp_path):
    mesh,mode,_,_,solve=api()
    sol=solve(mesh([0,.8],[0,.6],[0,.5],.12),1,1.2,mode('TE',1,0))
    assert sol.diagnostics['gradient_curl_residual']<1e-12
    x,w,E,H=sol.quadrature_fields()
    assert E.shape==H.shape==x.shape and np.all(w>0)
    assert np.all(np.isfinite(H))
    sol.save_npz(tmp_path/'field.npz')
    data=np.load(tmp_path/'field.npz',allow_pickle=False)
    assert data['field_coefficients'].size==sol.basis.N
    assert data['electric_field'].shape==E.shape


def test_invalid_inputs():
    mesh,mode,pml,_,solve=api()
    with pytest.raises(ValueError):mesh([0,0],[0,1],[0,1],.1)
    with pytest.raises(ValueError):mode('TM',1,0)
    with pytest.raises(ValueError):pml(((0,1),(0,1),(0,1)),((0,0),(0,0),(0,-1)))
    g=mesh([0,.8],[0,.6],[0,.5],.2)
    with pytest.raises(ValueError):solve(g,1,1.2,mode('TE',1,0),port_indices=(1.2+.01j,1.2))
    with pytest.raises(ValueError):solve(g,1,1.2,mode('TE',4,0),max_orders=(4,2))
