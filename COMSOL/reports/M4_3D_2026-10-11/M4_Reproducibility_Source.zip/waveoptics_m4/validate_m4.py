"""Actual 3D validation measurements; references from analytic_maxwell3d only."""
import json,csv,time,sys,gc
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import scipy,skfem,gmsh,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,str(Path(__file__).parent/'tests'))
from analytic_maxwell3d import params,vector_field,layer_rt,pml_reflection,manufactured
from waveoptics.maxwell3d import box_mesh,RectangularMode,CartesianPML,solve_guide,solve_pec,solve_s_matrix,_guide_system,_metrics,MaxwellSolution
R=Path(__file__).parent/'results';R.mkdir(exist_ok=True)
t0=time.monotonic();d=dict(executed_utc=datetime.now(timezone.utc).isoformat(),versions=dict(python=sys.version.split()[0],numpy=np.__version__,scipy=scipy.__version__,skfem=skfem.__version__,gmsh=gmsh.__version__,matplotlib=matplotlib.__version__),manufactured={},straight={},layer={},pml={})

def slope(rows,key):
    e=np.array([r[key] for r in rows]);h=np.array([r['h_max_um'] for r in rows]);return (np.log(e[:-1]/e[1:])/np.log(h[:-1]/h[1:])).tolist()
def z(v):return [float(v.real),float(v.imag)]
def checkpoint():
    (R/'validation_m4_checkpoint.json').write_text(json.dumps(d,indent=2)+'\n')
    print('completed',list(d['straight']),list(d['layer']),flush=True)
rows=[]
for h in [.2,.1,.05]:
    E=lambda x:manufactured(x,.6,.5);alpha=np.pi**2*(1/.6**2+1/.5**2)-(2*np.pi/1.7*1.1)**2
    s=solve_pec(box_mesh([0,.7],[0,.6],[0,.5],h),1.7,1.1,lambda x:alpha*E(x))
    rows.append(dict(h_nominal_um=h,field_l2_error=s.field_error(E),**s.diagnostics))
d['manufactured']=dict(rows=rows,field_slopes=slope(rows,'field_l2_error'));checkpoint()
# Reuse one assembled operator and LU for distinct incident modes at fixed data.
# Same kernel and extraction as solve_guide; references remain independent.
def prepare(geo,index,ports=('left','right'),pml=None):
    data=_guide_system(geo,1,index,(1.2,1.2),(2,2),ports,pml)
    basis,A,K,M,f,nv,Rmat,Ar,lu,channels,mode_data,free,Cp=data
    def run(kind,m,n):
        key=('left',kind,m,n);_,col,gamma=next(c for c in channels if c[0]==key)
        rhs=np.zeros(Ar.shape[0],complex);rhs[len(free):]=-2j*gamma*Cp[col-len(free)];u=lu.solve(rhs);E=Rmat@u;c=Cp@u[len(free):]
        out={k:complex((c[j-len(free)]-(k==key))*np.sqrt(g/gamma)) for k,j,g in channels}
        pc={k:complex(c[j]) for j,(k,_,_) in enumerate(mode_data)}
        diag=_metrics(geo,basis,A,K,M,f,E,Ar,u,rhs)
        diag.update(port_trace_modes=len(mode_data),propagating_channels=len(channels),output_power=float(sum(abs(v)**2 for v in out.values())),max_orders=[2,2],port_projection_deviation_norm=float(np.linalg.norm(Cp-np.eye(len(Cp)))))
        return MaxwellSolution(geo,basis,E,1,nv,diag,out,pc,pml)
    return run
mode_specs=[('TE',1,0),('TM',1,1)]
for kind,m,n in mode_specs:
    _,beta,gamma=params(kind,m,n,.8,.6,1.2,1)
    d['straight'][kind]=dict(rows=[],exact_S21=z(np.exp(1j*beta*.5)),exact_beta_per_um=float(beta.real),gamma_per_um=float(gamma.real))
for h in [.2,.1,.05]:
    run=None;s=None;x=w=E=H=None;gc.collect()
    run=prepare(box_mesh([0,.8],[0,.6],[0,.5],h),1.2)
    for kind,m,n in mode_specs:
        s=run(kind,m,n);exact=np.exp(1j*params(kind,m,n,.8,.6,1.2,1)[1]*.5)
        d['straight'][kind]['rows'].append(dict(h_nominal_um=h,S21=z(s.S[('right',kind,m,n)]),S11=z(s.S[('left',kind,m,n)]),S21_error=abs(s.S[('right',kind,m,n)]-exact),field_l2_error=s.field_error(lambda x:vector_field(x,kind,m,n,.8,.6,1.2,1)),**s.diagnostics))
        if h==.05:
            np.savez_compressed(R/f'straight_{kind}.npz',vertices=s.geometry.mesh.p,tetrahedra=s.geometry.mesh.t,edges=s.geometry.mesh.edges,field_coefficients=s.coefficients,wavelength_um=s.wavelength_um)
            x,w,E,H=s.quadrature_fields();centres=s.geometry.mesh.p[:,s.geometry.mesh.t].mean(axis=1)
            np.savez_compressed(R/f'field_plot_{kind}.npz',centres=centres,E=np.sum(E*w[None,...],axis=2)/w.sum(axis=1)[None,:])
    checkpoint()
for kind,_,_ in mode_specs:
    a=d['straight'][kind];a['transmission_slopes']=slope(a['rows'],'S21_error');a['field_slopes']=slope(a['rows'],'field_l2_error')
for loss in [0,.03]:
    indices=[1.2,1.6+1j*loss,1.2];idx=lambda x:np.where((x[2]>.15)&(x[2]<.35),indices[1],indices[0])
    run=None;s=None;x=w=E=H=None;gc.collect()
    run=prepare(box_mesh([0,.8],[0,.6],[0,.15,.35,.5],.045),idx)
    for kind,m,n in mode_specs:
        s=run(kind,m,n);r,t=layer_rt(kind,m,n,.8,.6,indices,[.15,.2,.15],1)
        d['layer'][f'{kind}_{loss}']=dict(S11=z(s.S[('left',kind,m,n)]),S21=z(s.S[('right',kind,m,n)]),exact_S11=z(r),exact_S21=z(t),reflection_error=abs(s.S[('left',kind,m,n)]-r),transmission_error=abs(s.S[('right',kind,m,n)]-t),exact_output_power=abs(r)**2+abs(t)**2,**s.diagnostics)
    checkpoint()
d['pml']={'TE':[],'TM':[]}
for strength in [0,1.2,4]:
    p=CartesianPML(((0,.8),(0,.6),(0,.5)),((0,0),(0,0),(0,.3)),strength=strength)
    run=None;s=None;x=w=E=H=None;gc.collect()
    run=prepare(box_mesh([0,.8],[0,.6],[0,.5,.8],.05),1.2,ports=('left',),pml=p)
    for kind,m,n in mode_specs:
        s=run(kind,m,n);r=s.S[('left',kind,m,n)];beta=params(kind,m,n,.8,.6,1.2,1)[1];exact_r=pml_reflection(beta,.8,.3,strength,2)
        d['pml'][kind].append(dict(strength=strength,S11=z(r),exact_S11=z(exact_r),reflection_amplitude=abs(r),exact_reflection_amplitude=abs(exact_r),reflection_error=abs(r-exact_r),**s.diagnostics))
    checkpoint()
run=None;s=None;x=w=E=H=None;gc.collect()
g=box_mesh([0,.4,.8],[0,.3,.6],[0,.15,.35,.5],.13)
idx=lambda x:np.where((x[0]>.4)&(x[1]>.3)&(x[2]>.15)&(x[2]<.35),1.6,1.2)
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
mesh=g.mesh;face=mesh.f2t[:,mesh.f2t[1]>=0]
adj=csr_matrix((np.ones(face.shape[1]),(face[0],face[1])),shape=(mesh.t.shape[1],)*2)
components,_=connected_components(adj+adj.T)
fc=mesh.p[:,mesh.facets[:,mesh.boundary_facets()]].mean(axis=1);bd=np.asarray(g.metadata['bounds'])
outer=np.any((abs(fc-bd[:,0,None])<1e-9)|(abs(fc-bd[:,1,None])<1e-9),axis=0)
v=mesh.p[:,mesh.t];volume=float(np.sum(abs(np.linalg.det(np.moveaxis(v[:,1:]-v[:,:1],2,0))))/6)
assert components==1 and np.all(outer) and abs(volume-.24)<1e-12
d['geometry_checks']=dict(connected_components=int(components),internal_exposed_faces=int(np.sum(~outer)),volume_um3=volume,exact_volume_um3=.24)
S,ch=solve_s_matrix(g,1,idx,port_indices=(1.2,1.2))
d['mode_conversion']=dict(channels=[list(k) for k in ch],reciprocity_residual=float(np.linalg.norm(S-S.T)),unitarity_residual=float(np.linalg.norm(S.conj().T@S-np.eye(len(S)))),TE10_to_TM11_amplitude=float(abs(S[ch.index(('right','TM',1,1)),ch.index(('left','TE',1,0))])))
np.savez_compressed(R/'mode_conversion_S.npz',S=S,channels=np.array([':'.join(map(str,k)) for k in ch]))
g=box_mesh([0,.8],[0,.6],[0,.5],.1);cut=[]
for order in [1,2,3]:
    s=solve_guide(g,1,1.2,RectangularMode('TE',1,0),max_orders=(order,order));cut.append(dict(max_order=order,S21=z(s.S[('right','TE',1,0)]),error=abs(s.S[('right','TE',1,0)]-np.exp(1j*params('TE',1,0,.8,.6,1.2,1)[1]*.5)),**s.diagnostics))
d['port_cutoff']=cut;d['elapsed_seconds']=time.monotonic()-t0
(R/'validation_m4.json').write_text(json.dumps(d,indent=2)+'\n')
with (R/'convergence_m4.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['benchmark','h_nominal_um','h_max_um','tetrahedra','edge_dofs','free_dofs','field_l2_error','complex_S21_error'])
    for name,group in [('manufactured',d['manufactured'])]+[(p,d['straight'][p]) for p in ['TE','TM']]:
        for r in group['rows']:w.writerow([name,*[r[k] for k in ['h_nominal_um','h_max_um','tetrahedra','edge_dofs','free_dofs','field_l2_error']],r.get('S21_error','')])
fig,axes=plt.subplots(1,2,figsize=(9,3.5),constrained_layout=True)
for kind in ['TE','TM']:
    rows=d['straight'][kind]['rows'];axes[0].loglog([r['h_max_um'] for r in rows],[r['S21_error'] for r in rows],'o-',label=kind+' S21')
    axes[1].loglog([r['h_max_um'] for r in rows],[r['field_l2_error'] for r in rows],'o-',label=kind+' E')
r=d['manufactured']['rows'];axes[1].loglog([v['h_max_um'] for v in r],[v['field_l2_error'] for v in r],'s-',label='Manufactured E')
for ax in axes:ax.set_xlabel('Actual maximum tetrahedron edge (um)');ax.set_ylabel('Error');ax.grid(True,which='both',alpha=.3);ax.legend()
fig.savefig(R/'convergence_m4.png',dpi=180);plt.close(fig)
from matplotlib.tri import Triangulation
fig,axes=plt.subplots(2,2,figsize=(9,6),constrained_layout=True)
for i,kind in enumerate(['TE','TM']):
    f=np.load(R/f'field_plot_{kind}.npz');x=f['centres'];E=f['E'];dist=np.min(abs(x[1]-.3));keep=abs(x[1]-.3)<max(.025,dist+1e-8)
    # Cell-centre points can repeat in the same x,z projection; average them.
    xy=np.round(x[[0,2]][:,keep].T,12);unique,inv=np.unique(xy,axis=0,return_inverse=True);counts=np.bincount(inv)
    comp=1 if kind=='TE' else 2
    value=np.bincount(inv,weights=E[comp,keep].real)/counts;intensity=np.bincount(inv,weights=np.sum(abs(E[:,keep])**2,axis=0))/counts
    tri=Triangulation(unique[:,0],unique[:,1])
    for j,v in enumerate([value,intensity]):
        im=axes[i,j].tripcolor(tri,v,shading='gouraud',cmap='RdBu_r' if j==0 else 'viridis');fig.colorbar(im,ax=axes[i,j]);axes[i,j].set(xlabel='x (um)',ylabel='z (um)',title=kind+(' Re(Ey)' if kind=='TE' else ' Re(Ez)') if j==0 else kind+' |E|^2');axes[i,j].set_aspect('equal')
fig.savefig(R/'fields_m4.png',dpi=180);plt.close(fig)
print(json.dumps(dict(executed_utc=d['executed_utc'],elapsed_seconds=d['elapsed_seconds'],complete=True)),flush=True)
