"""3D time-harmonic Maxwell FEM, exp(-i omega t), lengths in micrometres.
Lowest-order tetrahedral Nedelec elements; PEC boxes, finite analytic rectangular
modal trace ports and Cartesian PML. Not a complete open-waveguide DtN solver.
"""
from dataclasses import dataclass,field
import math
import numpy as np
from scipy.sparse import csr_matrix,block_diag
from scipy.sparse.linalg import splu,norm as sparse_norm
from scipy.linalg import block_diag as dense_block_diag
from skfem import MeshTet,Basis,FacetBasis,ElementTetN1,BilinearForm,LinearForm,asm
from skfem.helpers import dot,curl
from .vector import _gmsh_start,_positive

Z0=376.730313668

@dataclass
class VolumeMesh:
    mesh:MeshTet
    region:np.ndarray
    metadata:dict=field(default_factory=dict)

def _breaks(values,name):
    x=np.asarray(values,float)
    if x.ndim!=1 or len(x)<2 or not np.all(np.isfinite(x)) or np.any(np.diff(x)<=0):
        raise ValueError(name+' must be finite strictly increasing coordinates.')
    return x

def box_mesh(x_breaks,y_breaks,z_breaks,h_um):
    """Conforming gmsh tetrahedral extrusion, spacing <=h/sqrt(3).
    Internal break planes are aligned. Actual tetrahedron diameter reported.
    Single-process gmsh; one call cannot overlap another gmsh invocation.
    """
    xs=_breaks(x_breaks,'x_breaks');ys=_breaks(y_breaks,'y_breaks');zs=_breaks(z_breaks,'z_breaks')
    h_nominal=_positive(h_um,'h_um');h=h_nominal/np.sqrt(3);gm=_gmsh_start('maxwell3d-box')
    try:
        g=gm.model.geo
        points={(i,j):g.addPoint(float(x),float(y),float(zs[0])) for i,x in enumerate(xs) for j,y in enumerate(ys)}
        horizontal={};vertical={}
        for i in range(len(xs)-1):
            for j in range(len(ys)):
                tag=g.addLine(points[i,j],points[i+1,j]);horizontal[i,j]=tag
                g.mesh.setTransfiniteCurve(tag,math.ceil((xs[i+1]-xs[i])/h-1e-12)+1)
        for i in range(len(xs)):
            for j in range(len(ys)-1):
                tag=g.addLine(points[i,j],points[i,j+1]);vertical[i,j]=tag
                g.mesh.setTransfiniteCurve(tag,math.ceil((ys[j+1]-ys[j])/h-1e-12)+1)
        surfaces=[]
        for i in range(len(xs)-1):
            for j in range(len(ys)-1):
                lines=[horizontal[i,j],vertical[i+1,j],-horizontal[i,j+1],-vertical[i,j]]
                tag=g.addPlaneSurface([g.addCurveLoop(lines)])
                g.mesh.setTransfiniteSurface(tag,'Left',[points[i,j],points[i+1,j],points[i+1,j+1],points[i,j+1]])
                surfaces.append((2,tag))
        for lo,hi in zip(zs[:-1],zs[1:]):
            out=g.extrude(surfaces,0,0,float(hi-lo),numElements=[math.ceil((hi-lo)/h-1e-12)],recombine=False)
            surfaces=[out[i] for i in range(len(out)-1) if out[i][0]==2 and out[i+1][0]==3]
        g.synchronize();gm.model.mesh.generate(3)
        tags,coords,_=gm.model.mesh.getNodes();p=coords.reshape(-1,3).T
        mapping={int(t):i for i,t in enumerate(tags)}
        types,_,connectivity=gm.model.mesh.getElements(3);cells=[]
        for typ,conn in zip(types,connectivity):
            if typ!=4:raise RuntimeError('First-order tetrahedra required.')
            cells.extend([[mapping[int(t)] for t in tet] for tet in conn.reshape(-1,4)])
        t=np.asarray(cells,int).T;used=np.unique(t);renumber=np.full(len(tags),-1,int);renumber[used]=np.arange(len(used))
        mesh=MeshTet(np.ascontiguousarray(p[:,used]),np.ascontiguousarray(renumber[t]));centres=mesh.p[:,mesh.t].mean(axis=1)
        region=np.searchsorted(zs[1:-1],centres[2])
        return VolumeMesh(mesh,region,dict(kind='box',bounds=[[float(v[0]),float(v[-1])] for v in [xs,ys,zs]],h_nominal_um=h_nominal,coordinate_spacing_bound_um=h))
    finally:gm.finalize()

@dataclass(frozen=True)
class RectangularMode:
    kind:str
    m:int
    n:int
    def __post_init__(self):
        if self.kind not in ('TE','TM') or not isinstance(self.m,(int,np.integer)) or not isinstance(self.n,(int,np.integer)) or self.m<0 or self.n<0:
            raise ValueError('Mode requires TE/TM and nonnegative integer indices.')
        if self.m+self.n==0 or (self.kind=='TM' and (not self.m or not self.n)):
            raise ValueError('TE00 and TM modes with zero index do not exist.')
    @property
    def key(self):return self.kind,int(self.m),int(self.n)
    def parameters(self,a,b,index,wavelength):
        kc2=(self.m*np.pi/a)**2+(self.n*np.pi/b)**2;k2=(2*np.pi/wavelength*index)**2
        if abs(k2-kc2)<1e-10*max(k2,kc2):raise ValueError('Cutoff modal port is unsupported.')
        beta=np.sqrt(k2-kc2+0j);gamma=beta if self.kind=='TE' else k2/beta
        return beta,gamma
    def transverse(self,x,bounds):
        a=bounds[0,1]-bounds[0,0];b=bounds[1,1]-bounds[1,0]
        u=x[0]-bounds[0,0];v=x[1]-bounds[1,0];mx=self.m*np.pi/a;ny=self.n*np.pi/b
        norm=np.sqrt((mx*mx+ny*ny)*a*b/(4 if self.m and self.n else 2))
        e=np.zeros_like(x,dtype=float)
        if self.kind=='TE':
            e[0]=-ny*np.cos(mx*u)*np.sin(ny*v)/norm;e[1]=mx*np.sin(mx*u)*np.cos(ny*v)/norm
        else:
            e[0]=mx*np.cos(mx*u)*np.sin(ny*v)/norm;e[1]=ny*np.sin(mx*u)*np.cos(ny*v)/norm
        return e

@dataclass(frozen=True)
class CartesianPML:
    physical_bounds:tuple
    thickness:tuple
    strength:float=4.
    power:int=2
    def __post_init__(self):
        b=np.asarray(self.physical_bounds,float);t=np.asarray(self.thickness,float)
        if b.shape!=(3,2) or t.shape!=(3,2) or not np.all(np.isfinite(b)) or not np.all(np.diff(b,axis=1)>0) or not np.all(np.isfinite(t)) or np.any(t<0):
            raise ValueError('PML requires increasing 3D bounds and nonnegative left/right thicknesses.')
        if not np.isfinite(self.strength) or self.strength<0 or not isinstance(self.power,int) or self.power<1:raise ValueError('Invalid PML strength/power.')
    @property
    def outer_bounds(self):
        b=np.asarray(self.physical_bounds,float).copy();t=np.asarray(self.thickness,float);b[:,0]-=t[:,0];b[:,1]+=t[:,1];return b
    def stretches(self,x):
        s=np.ones_like(x,dtype=complex)
        for j in range(3):
            for side in range(2):
                thickness=self.thickness[j][side]
                if thickness:
                    distance=np.maximum(self.physical_bounds[j][0]-x[j],0) if side==0 else np.maximum(x[j]-self.physical_bounds[j][1],0)
                    s[j]+=1j*self.strength*(distance/thickness)**self.power
        return s
    def tensor(self,x):
        s=self.stretches(x);return np.prod(s,axis=0)[None,...]/s**2

def _index(index,x):
    value=index(x) if callable(index) else index
    n=np.broadcast_to(np.asarray(value,complex),x.shape[1:]).copy()
    if not np.all(np.isfinite(n)) or np.any(n.real<=0) or np.any(n.imag<0):raise ValueError('n must be finite passive with positive real part.')
    return n

@BilinearForm(dtype=complex)
def _stiff(u,v,w):return dot(w.invT*curl(u),curl(v))
@BilinearForm(dtype=complex)
def _mass(u,v,w):return dot(w.eps*u,v)
@LinearForm
def _overlap(v,w):return dot(w.mode,v)
@LinearForm(dtype=complex)
def _load(v,w):return dot(w.source,v)

def _assemble(geometry,wavelength,index,pml=None,source=None):
    wl=_positive(wavelength,'wavelength_um');basis=Basis(geometry.mesh,ElementTetN1(),intorder=7)
    x=np.asarray(basis.global_coordinates());nv=_index(index,x)
    if pml is not None:
        if not np.allclose(np.asarray(geometry.metadata['bounds']),pml.outer_bounds,rtol=0,atol=1e-9):raise ValueError('Mesh and PML outer bounds differ.')
        T=pml.tensor(x)
    else:T=np.ones_like(x,dtype=complex)
    K=asm(_stiff,basis,invT=1/T);M=asm(_mass,basis,eps=nv[None,...]**2*T);A=K-(2*np.pi/wl)**2*M
    f=np.zeros(basis.N,complex)
    if source is not None:
        s=np.asarray(source(x),complex)
        if s.shape!=x.shape or not np.all(np.isfinite(s)):raise ValueError('Source must return finite vector of shape (3,cells,quadrature).')
        f=asm(_load,basis,source=s)
    return basis,A,K,M,f,nv

def _gradient(mesh):
    edges=mesh.edges;ne=edges.shape[1]
    return csr_matrix((np.tile([-1.,1.],ne),(np.repeat(np.arange(ne),2),edges.T.ravel())),shape=(ne,mesh.p.shape[1]))

def _metrics(geometry,basis,A,K,M,f,E,Ar,u,fr):
    mesh=geometry.mesh;G=_gradient(mesh)
    vertices=np.setdiff1d(np.arange(mesh.p.shape[1]),np.unique(mesh.facets[:,mesh.boundary_facets()]))
    load=M@E+f/(2*np.pi/basis._m4_wavelength)**2
    gauss=np.asarray(G[:,vertices].T@load)
    hmax=float(np.linalg.norm(mesh.p[:,mesh.edges[1]]-mesh.p[:,mesh.edges[0]],axis=0).max())
    return dict(tetrahedra=int(mesh.t.shape[1]),vertices=int(mesh.p.shape[1]),edge_dofs=int(basis.N),free_dofs=int(Ar.shape[0]),h_max_um=hmax,
        linear_residual=float(np.linalg.norm(Ar@u-fr)/max(np.linalg.norm(fr),np.finfo(float).tiny)),
        weak_gauss_residual=float(np.linalg.norm(gauss)/max(np.linalg.norm(load),np.finfo(float).tiny)),
        gradient_curl_residual=float(sparse_norm(K@G)/max(sparse_norm(K)*sparse_norm(G),np.finfo(float).tiny)))

def _nested_order(A,coordinates):
    """Geometric structural-graph separators, followed by leaf RCM ordering."""
    from scipy.sparse.csgraph import reverse_cuthill_mckee
    graph=A.tocsr().copy();graph.data=np.ones(graph.nnz,float)
    def recurse(ids):
        adj=graph[ids][:,ids]
        if len(ids)<=128:return ids[reverse_cuthill_mckee(adj,symmetric_mode=True)]
        xx=coordinates[:,ids];axis=np.argmax(np.ptp(xx,axis=1))
        sort=np.argsort(xx[axis],kind='stable');left=np.zeros(len(ids),bool);left[sort[:len(ids)//2]]=True
        lc=left & ((adj@(~left).astype(float))>0);rc=(~left)&((adj@left.astype(float))>0)
        sep=lc if lc.sum()<rc.sum() else rc
        if sep.sum()>.6*len(ids) or not sep.any():return ids[reverse_cuthill_mckee(adj,symmetric_mode=True)]
        return np.concatenate([recurse(ids[left&~sep]),recurse(ids[~left&~sep]),recurse(ids[sep])])
    return recurse(np.arange(A.shape[0]))

@dataclass
class _OrderedLU:
    factor:object
    permutation:np.ndarray
    def solve(self,rhs):
        value=self.factor.solve(rhs[self.permutation]);out=np.empty_like(value);out[self.permutation]=value;return out

def _factor(A,coordinates):
    p=_nested_order(A,coordinates)
    return _OrderedLU(splu(A[p][:,p].tocsc(),permc_spec='NATURAL'),p)

@dataclass
class MaxwellSolution:
    geometry:VolumeMesh
    basis:Basis
    coefficients:np.ndarray
    wavelength_um:float
    index_quadrature:np.ndarray
    diagnostics:dict
    S:dict=field(default_factory=dict)
    port_coefficients:dict=field(default_factory=dict)
    pml:CartesianPML|None=None
    def quadrature_fields(self):
        E=self.basis.interpolate(self.coefficients)
        H=E.curl/(1j*(2*np.pi/self.wavelength_um)*Z0)
        if self.pml is not None:H=H/self.pml.tensor(np.asarray(self.basis.global_coordinates()))
        return np.asarray(self.basis.global_coordinates()),self.basis.dx,np.asarray(E),H
    def field_error(self,exact,physical_only=True):
        x,w,E,_=self.quadrature_fields();ex=np.asarray(exact(x))
        if self.pml is not None and physical_only:
            b=np.asarray(self.pml.physical_bounds);mask=np.all((x>=b[:,0,None,None]-1e-10)&(x<=b[:,1,None,None]+1e-10),axis=0);w=w*mask
        return float(np.sqrt(np.sum(np.sum(abs(E-ex)**2,axis=0)*w)/np.sum(np.sum(abs(ex)**2,axis=0)*w)))
    def save_npz(self,path):
        x,w,E,H=self.quadrature_fields()
        np.savez_compressed(path,vertices=self.geometry.mesh.p,tetrahedra=self.geometry.mesh.t,region=self.geometry.region,
          edges=self.geometry.mesh.edges,field_coefficients=self.coefficients,wavelength_um=self.wavelength_um,
          quadrature_points=x,quadrature_weights=w,index_quadrature=self.index_quadrature,electric_field=E,magnetic_field=H,
          pml_physical_bounds=np.asarray(self.pml.physical_bounds) if self.pml else np.empty((0,2)),
          pml_thickness=np.asarray(self.pml.thickness) if self.pml else np.empty((0,2)),
          pml_strength=np.array(self.pml.strength if self.pml else 0.),pml_power=np.array(self.pml.power if self.pml else 0),
          port_keys=np.array([':'.join(map(str,k)) for k in self.port_coefficients]),port_coefficients=np.array(list(self.port_coefficients.values())),
          field_kind=np.array('total'),S_keys=np.array([':'.join(map(str,k)) for k in self.S]),S_values=np.array(list(self.S.values())))

def solve_pec(geometry,wavelength_um,index,source):
    """Vector volume-driven PEC problem; caller supplies f, not electric current J."""
    basis,A,K,M,f,nv=_assemble(geometry,wavelength_um,index,source=source);basis._m4_wavelength=wavelength_um
    free=np.setdiff1d(np.arange(basis.N),basis.get_dofs().all());Ar=A[free][:,free].tocsc();fr=f[free]
    coordinates=geometry.mesh.p[:,geometry.mesh.edges[:,free]].mean(axis=1)
    u=_factor(Ar,coordinates).solve(fr);E=np.zeros(basis.N,complex);E[free]=u
    diag=_metrics(geometry,basis,A,K,M,f,E,Ar,u,fr)
    return MaxwellSolution(geometry,basis,E,wavelength_um,nv,diag)

def _modes(max_orders):
    if len(max_orders)!=2 or any(not isinstance(i,int) or i<1 for i in max_orders):raise ValueError('max_orders requires two positive integers.')
    modes=[]
    for m in range(max_orders[0]+1):
        for n in range(max_orders[1]+1):
            if m+n:modes.append(RectangularMode('TE',m,n))
            if m and n:modes.append(RectangularMode('TM',m,n))
    return modes

def _trace(mesh,edges,mode,bounds):
    from numpy.polynomial.legendre import leggauss
    q,w=leggauss(8);q=(q+1)/2;w=w/2
    a=mesh.p[:,mesh.edges[0,edges]];delta=mesh.p[:,mesh.edges[1,edges]]-a
    x=a[:,:,None]+delta[:,:,None]*q
    return np.sum(np.sum(mode.transverse(x,bounds)*delta[:,:,None],axis=0)*w,axis=1)

def _guide_system(geometry,wavelength_um,index,port_indices,max_orders,ports,pml):
    if not ports or len(set(ports))!=len(ports) or any(p not in ('left','right') for p in ports):raise ValueError('ports must be left and/or right once each.')
    if port_indices is None:
        if callable(index) or np.ndim(index):raise ValueError('Explicit real port_indices required for variable index.')
        port_indices=(index,index)
    if len(port_indices)!=2 or any(not np.isfinite(n) or np.iscomplex(n) or float(np.real(n))<=0 for n in port_indices):raise ValueError('Ports require positive real lossless indices.')
    bounds=np.asarray(geometry.metadata['bounds']);a,b=np.diff(bounds[:2],axis=1).ravel()
    if pml:
        if np.any(np.asarray(pml.thickness)[:2]):raise ValueError('Rectangular modal ports do not support transverse PML.')
        for port in ports:
            if pml.thickness[2][0 if port=='left' else 1]>0:raise ValueError('A modal port cannot lie behind a PML.')
    basis,A,K,M,f,nv=_assemble(geometry,wavelength_um,index,pml);basis._m4_wavelength=wavelength_um
    mesh=geometry.mesh;boundary=basis.get_dofs().all();free=np.setdiff1d(np.arange(basis.N),boundary)
    rows=list(free);cols=list(range(len(free)));values=[1.]*len(free);channels=[];gammas=[];mode_data=[];projections=[]
    modes=_modes(max_orders);ne=mesh.edges.shape[1]
    for port in ports:
        z=bounds[2,0 if port=='left' else 1];ix=0 if port=='left' else 1
        facets=mesh.facets_satisfying(lambda x:abs(x[2]-z)<1e-9,boundaries_only=True)
        edges=basis.get_dofs(facets=facets).all()
        # Remove the perimeter: these edges belong to a PEC sidewall.
        ep=mesh.p[:,mesh.edges[:,edges]]
        wall=np.any(np.all(abs(ep[:2]-bounds[:2,0,None,None])<1e-9,axis=1)|np.all(abs(ep[:2]-bounds[:2,1,None,None])<1e-9,axis=1),axis=0)
        edges=edges[~wall]
        traces=np.column_stack([_trace(mesh,edges,mode,bounds) for mode in modes])
        if np.linalg.matrix_rank(traces,tol=1e-10)<len(modes):raise ValueError('Port trace rank deficient: refine mesh or reduce max_orders.')
        facet=FacetBasis(mesh,ElementTetN1(),facets=facets,intorder=8)
        xf=np.asarray(facet.global_coordinates())
        overlaps=np.vstack([asm(_overlap,facet,mode=mode.transverse(xf,bounds))[edges] for mode in modes])
        projections.append(overlaps@traces)
        for j,mode in enumerate(modes):
            beta,gamma=mode.parameters(a,b,float(np.real(port_indices[ix])),wavelength_um)
            pos=len(free)+len(gammas);rows.extend(edges.tolist());cols.extend([pos]*len(edges));values.extend(traces[:,j].tolist())
            key=(port,*mode.key);gammas.append(gamma);mode_data.append((key,beta,gamma))
            if beta.real>0 and abs(beta.imag)<1e-12:channels.append((key,pos,gamma.real))
        # Check sampled uniform material at one near-port plane, diagnostic prerequisite.
        testx=mesh.p[:,mesh.facets[:,facets]].mean(axis=1);testx[2]=z+(1 if port=='left' else -1)*min(a,b)*1e-6
        if not np.allclose(_index(index,testx),port_indices[ix],rtol=0,atol=1e-8):raise ValueError('Index at port does not match its declared uniform index.')
    R=csr_matrix((values,(rows,cols)),shape=(ne,len(free)+len(gammas)))
    Cp=dense_block_diag(*projections)
    port_block=-1j*(Cp.T@(np.asarray(gammas)[:,None]*Cp))
    boundary=block_diag((csr_matrix((len(free),len(free))),csr_matrix(port_block)),format='csr')
    Ar=(R.T@A@R+boundary).tocsc()
    coordinates=mesh.p[:,mesh.edges[:,free]].mean(axis=1)
    modal_coordinates=np.array([[bounds[0].mean(),bounds[1].mean(),bounds[2,0 if k[0]=='left' else 1]] for k,_,_ in mode_data]).T
    lu=_factor(Ar,np.column_stack([coordinates,modal_coordinates]))
    return basis,A,K,M,f,nv,R,Ar,lu,channels,mode_data,free,Cp

def solve_guide(geometry,wavelength_um,index,incident_mode,incident_port='left',port_indices=None,max_orders=(2,2),ports=('left','right'),pml=None):
    """One incident analytic mode, arbitrary scalar passive n(x,y,z) in volume.
    Ports: finite modal trace span, exact analytic modal gamma. S normalized by
    real gamma. Input modal amplitude=1; E/H are not normalized to one watt.
    """
    data=_guide_system(geometry,wavelength_um,index,port_indices,max_orders,ports,pml)
    basis,A,K,M,f,nv,R,Ar,lu,channels,mode_data,free,Cp=data
    key=(incident_port,*incident_mode.key);hits=[c for c in channels if c[0]==key]
    if not hits:raise ValueError('Incident mode is absent, evanescent, or cutoff.')
    _,col,gamma=hits[0];fr=np.zeros(Ar.shape[0],complex);fr[len(free):]=-2j*gamma*Cp[col-len(free)]
    u=lu.solve(fr);E=R@u;c=Cp@u[len(free):]
    S={k:complex((c[j-len(free)]-(1 if k==key else 0))*np.sqrt(g/gamma)) for k,j,g in channels}
    pc={k:complex(c[j]) for j,(k,_,_) in enumerate(mode_data)}
    diag=_metrics(geometry,basis,A,K,M,f,E,Ar,u,fr);diag.update(port_trace_modes=len(mode_data),propagating_channels=len(channels),output_power=float(sum(abs(s)**2 for s in S.values())),max_orders=list(max_orders),port_projection_deviation_norm=float(np.linalg.norm(Cp-np.eye(len(Cp)))))
    return MaxwellSolution(geometry,basis,E,wavelength_um,nv,diag,S,pc,pml)

def solve_s_matrix(geometry,wavelength_um,index,port_indices=None,max_orders=(2,2)):
    """S for all retained propagating rectangular channels, reuse one LU."""
    data=_guide_system(geometry,wavelength_um,index,port_indices,max_orders,('left','right'),None)
    basis,A,K,M,f,nv,R,Ar,lu,channels,mode_data,free,Cp=data
    rhs=np.zeros((Ar.shape[0],len(channels)),complex)
    for i,(_,j,g) in enumerate(channels):rhs[len(free):,i]=-2j*g*Cp[j-len(free)]
    u=lu.solve(rhs);c=Cp@u[len(free):];S=np.empty((len(channels),len(channels)),complex)
    for i,(_,_,g0) in enumerate(channels):
        for k,(_,j,g) in enumerate(channels):S[k,i]=(c[j-len(free),i]-(i==k))*np.sqrt(g/g0)
    return S,[key for key,_,_ in channels]
