"""Reproducible 3D rectangular guide, layer and PML demonstrations."""
import argparse,json
from pathlib import Path
import numpy as np
from .maxwell3d import box_mesh,RectangularMode,CartesianPML,solve_guide,solve_s_matrix

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',choices=['straight','layer','pml'],default='straight')
    p.add_argument('--mode',choices=['TE10','TM11'],default='TE10')
    p.add_argument('--wavelength',type=float,default=1.)
    p.add_argument('--h',type=float,default=.1)
    p.add_argument('--index',type=float,default=1.2)
    p.add_argument('--layer-index',type=complex,default=1.6)
    p.add_argument('--pml-strength',type=float,default=4.)
    p.add_argument('--max-order',type=int,default=2)
    p.add_argument('--full-s',action='store_true')
    p.add_argument('--out',type=Path,default=Path('maxwell3d_output'))
    args=p.parse_args();out=args.out;out.mkdir(parents=True,exist_ok=True)
    mode=RectangularMode('TE',1,0) if args.mode=='TE10' else RectangularMode('TM',1,1)
    n=args.index;pml=None;ports=('left','right');zs=[0,.5]
    if args.case=='layer':
        zs=[0,.15,.35,.5];n=lambda x:np.where((x[2]>.15)&(x[2]<.35),args.layer_index,args.index)
    if args.case=='pml':
        zs=[0,.5,.8];ports=('left',);pml=CartesianPML(((0,.8),(0,.6),(0,.5)),((0,0),(0,0),(0,.3)),strength=args.pml_strength)
    geo=box_mesh([0,.8],[0,.6],zs,args.h)
    sol=solve_guide(geo,args.wavelength,n,mode,port_indices=(args.index,args.index),max_orders=(args.max_order,)*2,ports=ports,pml=pml)
    sol.save_npz(out/'fields.npz')
    summary=dict(case=args.case,mode=args.mode,diagnostics=sol.diagnostics,S={':'.join(map(str,k)):[v.real,v.imag] for k,v in sol.S.items()})
    if args.full_s:
        if pml is not None:p.error('--full-s requires two ports; not available for pml case.')
        S,channels=solve_s_matrix(geo,args.wavelength,n,port_indices=(args.index,args.index),max_orders=(args.max_order,)*2)
        np.savez_compressed(out/'S_matrix.npz',S=S,channels=np.array([':'.join(map(str,k)) for k in channels]))
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
