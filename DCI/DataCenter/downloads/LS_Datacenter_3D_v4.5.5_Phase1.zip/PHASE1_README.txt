LS Datacenter 3D v4.5.5. Includes 3 full source files and report.
46/46 regression checks passed. Browser test and screenshots: https://github.com/kimheeseo/LSCNS/actions/runs/38104463902
Software WebGL FPS measurements are NOT hardware benchmarks. Conceptual CAD/BIM caveat retained.
