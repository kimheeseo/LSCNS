LS Datacenter 3D v4.6.2 Phase 4 full source package.
HTML + Extensions JS/CSS + Phase2A/Phase2B JS/CSS files should remain side-by-side in the same folder.
Latest GitHub: https://github.com/kimheeseo/LSCNS/tree/main/DCI/DataCenter
Run website: https://kimheeseo.github.io/LSCNS/DCI/DataCenter/LS_Datacenter_3D.html?v=4.6.2
Static geometry persisted to GPU buffers and conservative fiber/power/cooling route segment frustum culling. 46 Phase1 + 62 Phase2 browser checks passed. Phase4 sampled CI software WebGL 12.9→13.6 FPS medium and 19.4→19.3 FPS low; fluctuations prevent definitive FPS speedup claims. No physical-phone or PC GPU benchmark.
All dimensions are conceptual, not measured CAD/BIM. See Phase4_v4.6.2_StaticGPU_Performance_Report.md.
