데이터센터 구성과 설계 계산 백서 v1.4 — 사례 B GitHub 공통 BOM 엔진 교차검산 재현 패키지
기준일: 2026-10-16

1. 검증 범위
- 입력: DGX H100 8대(서버당 GPU 8개) / 2랙 / 활성 400G DR4 광링크 64개(각 30m)
- 테스트 엔진: kimheeseo/LSCNS / DCI/DataCenter/phase7-bom-engine.js
- GitHub 원본 blob SHA: 19b6f48b9c9b95b40a39a4c70463bc103b9ff9d2
- 테스트 결과: Node.js 19개 assertion 통과
- 원본 리포지토리: https://github.com/kimheeseo/LSCNS/blob/main/DCI/DataCenter/phase7-bom-engine.js

2. 설치 환경
- Node.js v18 이상
- Python 3.9 이상 (백서 산식 재계산용)
- Git CLI (원본 동일성 확인 시)
- 패키지 별도 의존성 없음.

3. 재실행
- git hash-object phase7-bom-engine.js
  위에서 나오는 결과가 19b6f48b9c9b95b40a39a4c70463bc103b9ff9d2여야 합니다.
- node validate_phase7_caseB.cjs
- python validate_reference.py
- 결과: validation_result.json 및 caseB_comparison.json

4. 결과 해석
- 공통 엔진의 counts 9개를 직접 계산합니다: rackCount, gpuServerCount, gpuCount,
  nicCount, leafCount, spineCount, coreCount, opticalLinkCount, totalOpticalLengthM.
- 백서와 직접 항목이 겹치는 5개 값은 입력이 동일할 때 일치합니다.
- rackCount=2는 엔진이 최소 랙 수를 산정한 결과가 아니라 packet 입력 반영입니다.
- nicCount=64는 NIC/서버=8이란 가정값을 사용한 합산으로 물리 NIC/OSFP/모듈 SKU 수량과 다릅니다.
- 64개 링크 단일 스위치는 교육용 평면 토폴로지이며 인증된 NVIDIA SuperPOD 네트워크 설계가 아닙니다.
- 사이트의 실제 웹 UI 결과, 다른 BOM 툴 계산, 전력/냉각/RU/광심수/시공 승인 및 실물 시험을 검증하지 않았습니다.

5. 파일 안내
- phase7-bom-engine.js: 원본과 Git blob SHA가 동일한 공통 엔진
- caseB_packet.json: 입력 fixture
- caseB_reference.json: 소스 출력 기준의 9개 counts 값
- make_fixture.py: JSON 입력 및 기준 파일 생성
- validate_phase7_caseB.cjs: 실제 코드 구동·장애 회귀시험
- validate_reference.py: 독립 백서 수식 직접 검산
- validation_result.json: 원본 코드 실행 결과
- caseB_comparison.json: 백서/엔진 직접 비교 및 엔진 미지원 변수 구분

주의: 이 패키지의 코드 실행은 GitHub Pages 웹화면 UI 검증과 별개이며 구매·시공 승인 근거가 아닙니다.
