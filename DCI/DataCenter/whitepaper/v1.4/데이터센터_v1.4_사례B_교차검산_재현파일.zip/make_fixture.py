import json
from pathlib import Path
P=Path(__file__).resolve().parent
p={
 'schemaVersion':'lsdc-twin-bom/1.0','createdAt':'2026-10-16T00:00:00Z',
 'units':{'power':'kW','length':'m','temperature':'degC','flow':'L/min','loss':'dB','time':'min'},
 'assumptionNotice':'교육·설계 검토용 가정값 · 공식 제품 사양 아님',
 'facility':{'profile':'aidc','name':'Case B DGX H100 64 GPU (independent verification fixture)',
  'rackCount':2,'rackPowerKw':41.8,'gpuServerRatio':1,
  'cooling':{'mode':'air','airPct':100,'rearDoorPct':0,'dlcPct':0,'capacityKw':90},
  'redundancy':'N','targetPue':1.3,'outdoorC':32},
 'compute':{'gpuServerCount':8,'gpuPerServer':8},
 'network':{'nicPerServer':8},
 'optical':{'cpoMode':'pluggable','assumptions':{'gpuPerServer':8,'nicPerServer':8},
 'topology':{'type':'single_switch_caseB','portSpeed':'400G',
 'nodes':[{'id':f'dgx{i+1}','name':f'DGX-H100-{i+1}','layer':'Rack'} for i in range(8)]+[{'id':'q2','name':'Quantum-2 single switch (case B illustrative)','layer':'Spine'}],
 'links':[{'id':f'cB-{i+1:03d}','from':f'dgx{i//8+1}','to':'q2','type':'DR4 SMF MPO-12','fiber':'SMF','cores':12,'lengthM':30,'speed':'400G','down':False} for i in range(64)]}}
}
(P/'caseB_packet.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
ref={'rackCount':2,'gpuServerCount':8,'gpuCount':64,'nicCount':64,'leafCount':0,'spineCount':1,'coreCount':0,'opticalLinkCount':64,'totalOpticalLengthM':1920}
(P/'caseB_reference.json').write_text(json.dumps(ref,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('fixture: 64 links, 9 source engine outputs')
