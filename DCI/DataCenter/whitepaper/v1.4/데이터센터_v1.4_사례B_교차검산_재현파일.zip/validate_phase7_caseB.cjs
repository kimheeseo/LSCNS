'use strict';
const fs=require('fs'),assert=require('node:assert/strict'),path=require('path');
const p=__dirname;
const {calculate}=require(path.join(p,'phase7-bom-engine.js'));
const fixture=JSON.parse(fs.readFileSync(path.join(p,'caseB_packet.json'),'utf8'));
const expected=JSON.parse(fs.readFileSync(path.join(p,'caseB_reference.json'),'utf8'));
let assertions=0;
function eq(got,expect,label){assert.deepStrictEqual(got,expect,label);assertions++;}
const baseline=calculate(fixture);
Object.entries(expected).forEach(([k,expectedValue])=>eq(baseline.counts[k],expectedValue,k));
eq(baseline.rows.length,9,'row count');
eq(baseline.schema,'lsdc/phase7-bom-engine/1.0','schema id');
// An optical break is excluded, and the remaining 63 links give 1890m.
let fault=structuredClone(fixture);fault.optical.topology.links[0].down=true;
let failed=calculate(fault);eq(failed.counts.opticalLinkCount,63,'fault link count');eq(failed.counts.totalOpticalLengthM,1890,'fault length');
// Copper exclusion on media field, even if present in array.
let copper=structuredClone(fixture);copper.optical.topology.links[0].media='copper';
let cu=calculate(copper);eq(cu.counts.opticalLinkCount,63,'copper link count');eq(cu.counts.totalOpticalLengthM,1890,'copper length');
// Missing length prevents a claim about total length (not coerced to 0).
let incomplete=structuredClone(fixture);incomplete.optical.topology.links[0].lengthM=null;
let inc=calculate(incomplete);eq(inc.counts.totalOpticalLengthM,null,'missing length');
// Incorrect schema rejected.
assert.throws(()=>calculate({schemaVersion:'wrong'}),/lsdc-twin-bom\/1.0/);assertions++;
// Rack count does not automatically increment topology or servers if explicitly stated.
let revised=structuredClone(fixture);revised.facility.rackCount=3;
let mod=calculate(revised);eq(mod.counts.rackCount,3,'explicit rack change');eq(mod.counts.gpuServerCount,8,'server count holds');
const result={runAt:'2026-10-16',source:{name:'phase7-bom-engine.js',repo:'kimheeseo/LSCNS',gitBlobSha:'19b6f48b9c9b95b40a39a4c70463bc103b9ff9d2'},
runType:'local_Node_js_against_GitHub_source_exact_blob',
fixture:'caseB_packet.json',baseline:baseline.counts,assertionsPassed:assertions,
scenarios:{singleDown:{activeLinks:failed.counts.opticalLinkCount,lengthM:failed.counts.totalOpticalLengthM},oneCopper:{activeLinks:cu.counts.opticalLinkCount,lengthM:cu.counts.totalOpticalLengthM},missingLength:{totalOpticalLengthM:inc.counts.totalOpticalLengthM},rackCount3:{rackCount:mod.counts.rackCount,gpuServers:mod.counts.gpuServerCount}},
notCoveredByEngine:['rack RU','rack IT power','cooling capacity','optical module count','fiber cores','connector polarity','facilities annual kWh','Airflow']};
fs.writeFileSync(path.join(p,'validation_result.json'),JSON.stringify(result,null,2)+'\n');
console.log('PASS',assertions,'assertions');console.log(JSON.stringify(result,null,2));
