import json,math
from pathlib import Path
P=Path(__file__).resolve().parent
j=json.loads((P/'validation_result.json').read_text())
# All quantities below independent algebra, not an execution of the website or an external engineering solver.
math_book={
 'gpuCount':8*8,
 'gpuServerCount':math.ceil(64/8),
 'rackCount':math.ceil(8/math.floor((42-6)/8)),
 'rackRU':4*8+6,
 'rackPowerKw':4*10.2+1,
 'itPowerKw':2*(4*10.2+1),
 'opticalLinkCount':8*8,
 'physicalTwinPortModuleCount':8*4+32,
 'installedMpoAssemblies':8*8,
 'activeFiberCores':8*8*8,
 'embeddedFiberCores':8*8*12,
 'totalOpticalLengthM':8*8*30,
 'facilityPowerKw':(2*(4*10.2+1))*1.3,
 'annualFacilityKwh':(2*(4*10.2+1))*1.3*8760,
 'rackAirFlowM3H':(4*10.2+1)*1000/(1.2*1005*15)*3600,
}
for k,v in math_book.items():
 if isinstance(v,float): math_book[k]=round(v,5)
engine=j['baseline'];direct=['gpuCount','gpuServerCount','rackCount','opticalLinkCount','totalOpticalLengthM']
comparison=[{'name':k,'manual':math_book[k],'engine':engine.get(k),'status':'PASS' if math.isclose(math_book[k],engine[k],rel_tol=0,abs_tol=1e-7) else 'FAIL'} for k in direct]
assert all(x['status']=='PASS' for x in comparison)
known={'manualOnly':[k for k in math_book if k not in direct], 'matches':comparison,'reference':math_book,'sources':{'paper':'v1.3 §79–84','engine':j['source']},'limitations':['web UI untested','Case B fixture uses explicitly specified gpuServerCount, topology not auto-generated','nicPerServer=8 is a packet assumption, not a part number','rackCount is user supplied to engine, not a computed minimum','live web and compliance testing not performed']}
(P/'caseB_comparison.json').write_text(json.dumps(known,ensure_ascii=False,indent=2)+'\n')
print('Source overlap:',len(direct),'PASS; independent book formulas:',len(math_book))
for row in comparison:print(row)
